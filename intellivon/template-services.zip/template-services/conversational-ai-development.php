
<?php /* Template Name: Conversational AI Development */ ?>
<?php get_header(); ?>
<!-- Intellivon Menubar Start -->
<!-- Intellivon Menubar End -->
<!-- HERO SECTION -->
<div class="w-full bg-[#040E32] pt-0">
  <div class="flex">
    <div class="lg:w-1/2 flex flex-col gap-5 px-10 justify-center py-10 lg:py-0">
      <h1 class="font-bold text-4xl lg:text-5xl text-white">
        <span class="text-gradient">Unlock </span>
        Smarter AI Enterprise Communication With AI
      </h1>
      <p class="text-white text-lg font-medium">
        Connect your teams globally with AI-powered systems that streamline communication and boost collaboration securely and efficiently.
      </p>
      <a href="https://intellivon.com/ai-strategy-call-booking-confirmation/" target="_blank">
        <button
          class="w-fit flex gap-2 bg-gradient-to-r from-[#9A37B2] to-[#E61C42] text-white font-medium px-6 py-3 rounded-full shadow-lg hover:scale-105 transition border border-[#7C3BAF]">
          Talk to an AI Specialist
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd"
              d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
              fill="white" />
          </svg>
        </button>
      </a>
    </div>

    <div class="hidden lg:block right-0 top-0 w-1/2">
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/Hero-conversational-ai-development.webp"
        class="w-full h-full" />
    </div>
  </div>
</div>

<!-- Content Update Upto Here 30-07-2025 -->

<!-- OUR CLIENTS -->
<section class="w-full pt-10 lg:pt-0" style="
    background: linear-gradient(
      95deg,
      rgba(124, 59, 175, 0.3) 0.11%,
      rgba(230, 28, 66, 0.3) 80.8%
    );
  ">
  <div class="flex flex-wrap items-center">
    <!-- Left column: Heading -->
    <div class="w-full lg:w-2/3 lg:pl-10 px-10 lg:px-0">
      <div class="flex flex-col gap-5 items-start">
        <div class="text-md font-semibold text-[#656565]">OUR CLIENTS</div>
        <h2 class="text-4xl items-center font-bold text-black1 font-urbanist leading-snug tracking-[0.5px] gap-1">
          Clients Leveraging AI to 
          <span class="text-gradient">Revolutionize Communication</span>
        </h2>
        <p class="mb-4 md:mb-0 text-base font-medium text-grey1 mt-2 w-full tracking-[0.25px] pr-5 mb-12">
          Our clients leverage Intellivon’s AI solutions to transform communication, optimize workflows, and deliver personalized, efficient organization-wide enterprise communications.
        </p>
      </div>
    </div>
    <!-- Right column: Image -->
    <div class="w-full lg:w-1/3 p-10">
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/intellivon-client-image.webp"
        alt="Our Clients" width="620" height="550"
        class="w-full lg:h-full lg:mb-12 xl:mb-0 object-cover object-center rounded-md transition-all duration-300" />
    </div>
  </div>
</section>

<!-- SERVICES - MARQUEE -->
<section>
  <!-- Marquee logos -->
  <div class="w-full overflow-hidden whitespace-nowrap relative bg-[#10182C] py-5">
    <div class="marquee flex items-center gap-x-16 w-max max-w-none animate-marquee">
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/gold-gym.webp" alt="Gold Gym" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/sonangol.webp" alt="Sonangol" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/buzztime.webp" alt="Buzztime" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/hyundai.png" alt="Hyundai" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/rusam.webp" alt="Rusam" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <!-- repeat logos for continuous scroll -->
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/gold-gym.webp" alt="Gold Gym" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/sonangol.webp" alt="Sonangol" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/buzztime.webp" alt="Buzztime" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/hyundai.png" alt="Hyundai" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/rusam.webp" alt="Rusam" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <!-- repeat logos for continuous scroll -->
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/gold-gym.webp" alt="Gold Gym" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/sonangol.webp" alt="Sonangol" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/buzztime.webp" alt="Buzztime" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/hyundai.png" alt="Hyundai" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/rusam.webp" alt="Rusam" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <!-- repeat logos for continuous scroll -->
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/gold-gym.webp" alt="Gold Gym" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/sonangol.webp" alt="Sonangol" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/buzztime.webp" alt="Buzztime" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/hyundai.png" alt="Hyundai" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
      <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/rusam.webp" alt="Rusam" width="80"
        height="80" class="w-20 grayscale hover:grayscale-0" />
    </div>
  </div>
  <style>
    /* Marquee animation */
    @keyframes marquee {
      0% {
        transform: translateX(0);
      }

      100% {
        transform: translateX(-50%);
      }
    }

    .animate-marquee {
      animation: marquee 20s linear infinite;
    }
  </style>
</section>

<!-- OUR SERVICES -->
<section>
  <div class="bg-services-gradient relative px-5 lg:px-10 overflow-hidden">
    <div class="container flex flex-col items-center lg:pt-14 pb-4 py-5 gap-10">
      <!-- content -->
      <div class="w-full pr-5">
        <div class="w-full flex flex-col gap-5 items-start">
          <div class="text-md font-semibold text-[#656565]">OUR SERVICES</div>
          <h2 class="text-4xl font-bold text-black1 font-urbanist leading-snug tracking-[0.5px] w-full">
            <span class="text-gradient">
              Comprehensive AI Solutions for Seamless Enterprise Communication
            </span>
          </h2>
          <p class="mb-4 md:mb-0 text-base font-medium text-grey1 mt-2 w-full tracking-[0.25px] pr-5 mb-12">
            Our AI-enabled services streamline enterprise communication by combining email, chat, video, and collaboration tools to facilitate secure and efficient workflows across departments, remote teams, and global offices. 
          </p>
        </div>
      </div>

      <div class="bg-white rounded-3xl flex flex-col lg:flex-row gap-10 p-8 w-5/6 z-10" id="servicesContainer">
        <div class="flex flex-col gap-5 lg:w-1/3 h-[70vh] overflow-y-scroll pt-5 px-5" id="serviceButtons">
          <!-- Button 1 -->
          <div class="rounded-xl">
            <div
              class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
              AI-Powered Virtual Chatbots
            </div>
          </div>
          <!-- Button 2 -->
          <div class="rounded-xl">
            <div
              class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
              Real-Time Speech Recognition
            </div>
          </div>
          <!-- Button 3 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
            Predictive Analytics
          </div>
          <!-- Button 4 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
            Personalization Engines
          </div>
          <!-- Button 5 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
            AI-Enhanced Meeting Tools
          </div>
          <!-- Button 6 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
            Intelligent Workflow Automation
          </div>
          <!-- Button 7 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
            Security, Compliance & QA
          </div>
          <!-- Button 8 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
            Multimodal Communication
          </div>
        </div>

        <div class="lg:w-2/3 flex flex-col gap-5 lg:gap-10 mt-10" id="serviceContent">
          <!-- <div class="font-bold text-lg lg:text-2xl">
                            AI Strategy & Roadmapping
                        </div> -->

          <div class="grid gap-3 grid-cols-1 lg:grid-cols-2">
            <!-- button 1 -->
            <div class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
              <div
                class="text-md bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
                AI-Powered Virtual Chatbots
              </div>
            </div>

            <!-- button 2 -->
            <div class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
                Real-Time Speech Recognition
              </div>
            </div>

            <!-- button 3 -->
            <div class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
                Predictive Analytics
              </div>
            </div>

            <!-- button 4 -->
            <div class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
                Personalization Engines
              </div>
            </div>

            <!-- button 5 -->
            <div class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
                AI-Enhanced Meeting Tools
              </div>
            </div>

            <!-- button 6 -->
            <div class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
                Intelligent Workflow Automation
              </div>
            </div>

            <!-- button 7 -->
            <div class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
                Security, Compliance & QA
              </div>
            </div>

            <!-- button 8 -->
            <div class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">
                Multimodal Communication
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Background Decoration -->
    <div class="absolute top-0 right-0 w-[512px] h-[512px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512" fill="none">
        <g filter="url(#filter0_f_2_313)">
          <circle cx="422" cy="102" r="112" fill="#D200D2" />
        </g>
        <defs>
          <filter id="filter0_f_2_313" x="0.200012" y="-319.8" width="843.6" height="843.6" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_2_313" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="absolute bottom-0 left-0 w-[534px] h-[379px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="534" height="379" viewBox="0 0 534 379" fill="none">
        <g filter="url(#filter0_f_288_195)">
          <circle cx="112" cy="422" r="112" fill="#D200D2" fill-opacity="0.4" />
        </g>
        <defs>
          <filter id="filter0_f_288_195" x="-309.8" y="0.200012" width="843.6" height="843.6"
            filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_288_195" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="absolute bottom-0 left-[30%] w-[844px] h-[573px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="844" height="573" viewBox="0 0 844 573" fill="none">
        <g filter="url(#filter0_f_288_194)">
          <circle cx="422" cy="422" r="112" fill="#D200D2" />
        </g>
        <defs>
          <filter id="filter0_f_288_194" x="0.200012" y="0.200012" width="843.6" height="843.6"
            filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_288_194" />
          </filter>
        </defs>
      </svg>
    </div>
  </div>

  <script>
    const services = [
      {
        title: "AI-Powered Virtual Chatbots",
        description:
          "Our virtual assistants and chatbots provide 24/7 automated customer support, instantly resolving queries. We utilize intelligent routing to direct customer inquiries to the appropriate department or agent, ensuring seamless interactions across web, chat, email, and SMS channels.",
        points: [
"24/7 Customer Support",
"Intelligent Inquiry Routing",
"Multi-Channel Integration",
"Proactive Customer Engagement",
"Advanced NLU Capabilities",
"Analytics and Reporting",
        ],
      },
      {
        title: "Real-Time Speech Recognition",
        description:
          "We offer live transcription for calls, meetings, and conferences, along with automated meeting summaries and action extraction. Our system provides real-time sentiment and intent analysis, improving decision-making and communication outcomes.",
        points: [
"Real-time transcription",
"Automated actions",
"Sentiment and Intent Analysis",
"Voice Command Integration",
"Speech-to-Text Accuracy",
"Real-Time Language Translation",

        ],
      },
      {
        title: "Predictive Analytics",
        description:
          "Gain insights into customer behavior and communication trends with our predictive analytics tools. We provide data-driven recommendations for sales, support, and marketing teams, along with forecasting and anomaly detection tools to enhance operational efficiency.",
        points: [
"Customer behavior insights",
"Predictive recommendations",
"Anomaly detection",
"Sales Forecasting",
"Marketing Campaign Optimization",
"Operational Efficiency Enhancement",
        ],
      },

      {
        title: "Personalization Engines",
        description:
          "Our AI-driven personalization engines tailor communication to each customer's unique history and preferences. From personalized marketing campaigns to context-aware product recommendations, we help you connect with your customers in relevant ways.",
        points: [
"Tailored marketing campaigns",
"Context-aware recommendations",
"Enhanced customer engagement",
"Behavioral Data Analysis",
"Dynamic Content Customization",
"Real-Time User Profiling",
        ],
      },

      {
        title: "AI-Enhanced Meeting Tools",
        description:
          "Streamline meetings and collaboration with our AI-powered tools. Automated agenda setting, real-time translation for global teams, intelligent note-taking, and task assignments make collaboration smoother, more efficient, and accessible across all locations.",
        points: [
"Automated agenda setting",
"Real-time translation",
"Intelligent note-taking",
"Task Assignment Automation",
"Action Item Tracking",
"Meeting Summaries and Insights",
        ],
      },

      {
        title: "Intelligent Workflow Automation",
        description:
          "Our AI solutions automate scheduling, reminders, and follow-ups, reducing manual tasks and improving productivity. By integrating with CRM, ERP, and other business systems, we streamline internal communications and approvals, leading to increased efficiency.",
        points: [
"Automated scheduling",
"Seamless system integration",
"Streamlined communication",
"Automated Task Routing",
"Real-Time Workflow Monitoring",
"Intelligent Decision-Making Support",

        ],
      },

      {
        title: "Security, Compliance & QA",
        description:
          "We ensure data privacy and regulatory compliance with AI-driven monitoring, automated content moderation, and risk detection. With enterprise-grade encryption and access controls, your communications and data are secure.",
        points: [
"AI-driven monitoring",
"Content moderation",
"Enterprise-grade security",
"Automated Risk Detection",
"Regulatory Compliance Automation",
"Access Control Management",
        ],
      },

      {
        title: "Multimodal Communication",
        description:
          "Our AI-powered system automatically adjusts audio and video quality according to network conditions, ensuring seamless communication. Smart call routing and resource allocation improve large-scale event management, while real-time feedback enhances communication effectiveness.",
        points: [
"Adaptive media quality",
"Smart call routing",
"Real-time feedback",
"Dynamic Resource Allocation",
"Seamless Event Management",
"Optimized Network Performance",
        ],
      },
    ];

    const buttonsContainer = document.getElementById("serviceButtons");
    const contentContainer = document.getElementById("serviceContent");

    function renderButtons(activeIndex = 0) {
      buttonsContainer.innerHTML = "";
      services.forEach((service, index) => {
        const isActive = index === activeIndex;
        const btnWrapper = document.createElement("div");
        btnWrapper.className = `rounded-xl ${isActive ? "pl-1 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]" : ""
          }`;

        btnWrapper.innerHTML = `
                <div class="bg-white flex justify-between items-center rounded-xl font-bold text-sm lg:text-base px-3 py-4 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)] cursor-pointer" onclick="renderContent(${index})">
                <div class="w-full">${service.title}</div>
                ${isActive
            ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z" fill="url(#paint0_linear_2_494)"/>
                    <defs>
                    <linearGradient id="paint0_linear_2_494" x1="6.5" y1="7" x2="22" y2="13" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#7C3BAF"/>
                        <stop offset="1" stop-color="#E61C42"/>
                    </linearGradient>
                    </defs>
                </svg>`
            : ""
          }
                </div>
            `;
        buttonsContainer.appendChild(btnWrapper);
      });
    }

    function renderContent(index) {
      renderButtons(index);
      const service = services[index];

      contentContainer.innerHTML = `
            <div class="font-bold text-lg lg:text-2xl">${service.title}</div>
            
                <div class="text-[#333333] text-sm lg:text-base">${service.description
        }</div>
                <div class="grid gap-3 grid-cols-1 lg:grid-cols-2">
                ${service.points
          .map(
            (point) => `
                    <div class="pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
                    <div class="bg-gradient-to-r from-[#ceb0dc] via-[#dfaac9] to-[#eba7bf] flex justify-start items-center text-sm lg:text-md font-bold py-4 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">${point}</div>
                    </div>
                `
          )
          .join("")}
                </div>
            
            `;
    }
    // Initial Render
    renderButtons(0);
    renderContent(0);
  </script>
</section>

<!-- OUR PROCESS -->
<section class="bg-landingGen py-16 lg:py-24 bg-cover px-5 lg:px-10">
  <div class="container">
    <div class="flex items-end justify-between mt-6 mb-3">
      <!-- Heading -->
      <div class="flex flex-col gap-3 w-full">
        <div class="text-md font-semibold text-[#656565]">OUR PROCESS</div>
        <h2 class="text-4xl md:gap-3 items-center font-bold text-black1 font-urbanist leading-snug tracking-[0.5px]">
          Our Process for Building AI Enterprise Communication Systems
          <span class="text-gradient"> in 3 Steps </span>
        </h2>
        <p class="text-[#333333] w-full lg:w-3/4 text-base font-medium">
          Our proven approach, leveraging microservices and cloud-native technologies, enables businesses to enhance their communication systems with AI components that can be upgraded or added without disrupting operations or system integrity.
        </p>
      </div>
    </div>
    <!-- Consulting Cards -->
    <div id="consulting-cards" class="flex flex-col lg:flex-row justify-center bg-white mt-8">
      <!-- Step 1 -->
      <div class="card w-full lg:w-1/3 p-6 border-2 border-transparent bg-zinc-50 rounded-md" style="
          border-radius: 12px;
          background: linear-gradient(142deg, #fff 0%, #e0faff 99.14%);
        ">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-black2 font-light text-sm">Step 1</h3>
            <h3 class="text-black2 font-bold font-urbanist text-xl">
              Evaluate
            </h3>
          </div>
          <!-- ArrowRight SVG -->
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
            <path
              d="M29.4825 18.7501H6.25C5.91848 18.7501 5.60054 18.8818 5.36612 19.1162C5.1317 19.3507 5 19.6686 5 20.0001C5 20.3316 5.1317 20.6496 5.36612 20.884C5.60054 21.1184 5.91848 21.2501 6.25 21.2501H29.4825L20.365 30.3651C20.1303 30.5998 19.9984 30.9182 19.9984 31.2501C19.9984 31.5821 20.1303 31.9004 20.365 32.1351C20.5997 32.3698 20.9181 32.5017 21.25 32.5017C21.5819 32.5017 21.9003 32.3698 22.135 32.1351L33.385 20.8851C33.5014 20.769 33.5938 20.6311 33.6568 20.4792C33.7198 20.3273 33.7522 20.1645 33.7522 20.0001C33.7522 19.8357 33.7198 19.6729 33.6568 19.521C33.5938 19.3692 33.5014 19.2312 33.385 19.1151L22.135 7.86511C21.9003 7.6304 21.5819 7.49854 21.25 7.49854C20.9181 7.49854 20.5997 7.6304 20.365 7.86511C20.1303 8.09983 19.9984 8.41817 19.9984 8.75011C19.9984 9.08205 20.1303 9.4004 20.365 9.63511L29.4825 18.7501Z"
              fill="url(#paint0_linear_2_437)" />
            <defs>
              <linearGradient id="paint0_linear_2_437" x1="33.7522" y1="20.0001" x2="5" y2="20.0001"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF00E1" />
                <stop offset="1" stop-color="#000DFF" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div class="grid grid-cols-2 gap-1 mt-4">
          <div class="p-3 bg-[#F7F7F7] h-44">
            <!-- AccordianArrow SVG -->
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Identify communication challenges and define AI objectives.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Align solutions with your enterprise's specific communication needs.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Determine desired outcomes, such as clarity, feedback, or reduced delays.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Understand existing communication systems for effective AI integration.
            </p>
          </div>
        </div>
      </div>
      <!-- Step 2 -->
      <div class="card w-full lg:w-1/3 p-6 border-2 border-transparent rounded-md"
        style="background: linear-gradient(142deg, #fff 0%, #d4d6ff 99.14%)">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-black2 font-light text-sm">Step 2</h3>
            <h3 class="text-black2 font-bold font-urbanist text-xl">Explore</h3>
          </div>
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
            <path
              d="M29.4825 18.7501H6.25C5.91848 18.7501 5.60054 18.8818 5.36612 19.1162C5.1317 19.3507 5 19.6686 5 20.0001C5 20.3316 5.1317 20.6496 5.36612 20.884C5.60054 21.1184 5.91848 21.2501 6.25 21.2501H29.4825L20.365 30.3651C20.1303 30.5998 19.9984 30.9182 19.9984 31.2501C19.9984 31.5821 20.1303 31.9004 20.365 32.1351C20.5997 32.3698 20.9181 32.5017 21.25 32.5017C21.5819 32.5017 21.9003 32.3698 22.135 32.1351L33.385 20.8851C33.5014 20.769 33.5938 20.6311 33.6568 20.4792C33.7198 20.3273 33.7522 20.1645 33.7522 20.0001C33.7522 19.8357 33.7198 19.6729 33.6568 19.521C33.5938 19.3692 33.5014 19.2312 33.385 19.1151L22.135 7.86511C21.9003 7.6304 21.5819 7.49854 21.25 7.49854C20.9181 7.49854 20.5997 7.6304 20.365 7.86511C20.1303 8.09983 19.9984 8.41817 19.9984 8.75011C19.9984 9.08205 20.1303 9.4004 20.365 9.63511L29.4825 18.7501Z"
              fill="url(#paint0_linear_2_461)" />
            <defs>
              <linearGradient id="paint0_linear_2_461" x1="33.7522" y1="20.0001" x2="5" y2="20.0001"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF00E1" />
                <stop offset="1" stop-color="#000DFF" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div class="grid grid-cols-2 gap-1 mt-4">
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Select the optimal AI tools, such as TensorFlow, PyTorch, or Dialogflow.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Ensure AI tools scale and integrate with existing infrastructure.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Collect anonymized communication data for ethical model training.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Train AI models to understand your organization’s communication patterns.
            </p>
          </div>
        </div>
      </div>
      <!-- Step 3 -->
      <div class="card w-full lg:w-1/3 p-6 border-2 border-transparent rounded-md"
        style="background: linear-gradient(142deg, #fff 0%, #ffddfb 99.14%)">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-black2 font-light text-sm">Step 3</h3>
            <h3 class="text-black2 font-bold font-urbanist text-xl">Execute</h3>
          </div>
          <!-- Refresh SVG -->
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd"
              d="M14.1166 4.11654C14.351 3.88246 14.6687 3.75098 14.9999 3.75098C15.3312 3.75098 15.6489 3.88246 15.8833 4.11654L19.2166 7.44988C19.3912 7.62469 19.5101 7.84732 19.5582 8.08965C19.6063 8.33198 19.5816 8.58314 19.4871 8.81142C19.3925 9.03969 19.2325 9.23483 19.0271 9.3722C18.8218 9.50956 18.5803 9.58299 18.3333 9.58321H14.9999C12.2372 9.58321 9.58773 10.6807 7.63422 12.6342C5.68072 14.5877 4.58325 17.2372 4.58325 19.9999C4.58325 22.7625 5.68072 25.4121 7.63422 27.3656C9.58773 29.3191 12.2372 30.4165 14.9999 30.4165H15.8333C16.1648 30.4165 16.4827 30.5482 16.7171 30.7827C16.9516 31.0171 17.0833 31.335 17.0833 31.6665C17.0833 31.9981 16.9516 32.316 16.7171 32.5504C16.4827 32.7848 16.1648 32.9165 15.8333 32.9165H14.9999C11.5742 32.9165 8.2888 31.5557 5.86646 29.1333C3.44411 26.711 2.08325 23.4256 2.08325 19.9999C2.08325 16.5742 3.44411 13.2888 5.86646 10.8664C8.2888 8.44407 11.5742 7.08321 14.9999 7.08321H15.3166L14.1166 5.88321C13.8825 5.64883 13.751 5.33113 13.751 4.99988C13.751 4.66863 13.8825 4.35092 14.1166 4.11654ZM22.9166 8.33321C22.9166 8.00169 23.0483 7.68375 23.2827 7.44933C23.5171 7.21491 23.8351 7.08321 24.1666 7.08321H24.9999C28.4256 7.08321 31.711 8.44407 34.1334 10.8664C36.5557 13.2888 37.9166 16.5742 37.9166 19.9999C37.9166 23.4256 36.5557 26.711 34.1334 29.1333C31.711 31.5557 28.4256 32.9165 24.9999 32.9165H24.6833L25.8833 34.1165C26.0061 34.231 26.1046 34.369 26.1729 34.5223C26.2412 34.6756 26.2779 34.8412 26.2809 35.009C26.2839 35.1768 26.253 35.3436 26.1901 35.4992C26.1273 35.6549 26.0337 35.7962 25.915 35.9149C25.7963 36.0336 25.6549 36.1272 25.4992 36.1901C25.3436 36.2529 25.1769 36.2838 25.0091 36.2809C24.8412 36.2779 24.6757 36.2412 24.5224 36.1728C24.369 36.1045 24.231 36.006 24.1166 35.8832L20.7833 32.5499C20.6087 32.3751 20.4898 32.1524 20.4416 31.9101C20.3935 31.6678 20.4183 31.4166 20.5128 31.1883C20.6073 30.9601 20.7673 30.7649 20.9727 30.6276C21.1781 30.4902 21.4195 30.4168 21.6666 30.4165H24.9999C27.7626 30.4165 30.4121 29.3191 32.3656 27.3656C34.3191 25.4121 35.4166 22.7625 35.4166 19.9999C35.4166 17.2372 34.3191 14.5877 32.3656 12.6342C30.4121 10.6807 27.7626 9.58321 24.9999 9.58321H24.1666C23.8351 9.58321 23.5171 9.45151 23.2827 9.21709C23.0483 8.98267 22.9166 8.66473 22.9166 8.33321Z"
              fill="url(#paint0_linear_2_485)" />
            <defs>
              <linearGradient id="paint0_linear_2_485" x1="37.9166" y1="20.016" x2="2.08325" y2="20.016"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF00E1" />
                <stop offset="1" stop-color="#000DFF" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div class="grid grid-cols-2 gap-1 mt-4">
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Test AI models in controlled environments for accuracy and fairness.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Address bias or misclassification before full-scale deployment.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Deploy using CI/CD pipelines for a smooth and scalable implementation.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.7392 1H1V19H17.4348V13" stroke="#72C89A" stroke-width="1.5" stroke-linecap="round"
                stroke-linejoin="round" />
              <path d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387" stroke="#72C89A" stroke-width="1.5"
                stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Continuously monitor interactions and improve AI models over time.
            </p>
          </div>
        </div>
      </div>
    </div>
    <!-- Talk To Us button (mobile) -->
    <div class="md:hidden w-full flex items-center justify-center mt-4">
      <button type="button" class="relative px-4 py-2 text-white font-medium rounded-lg bg-white overflow-hidden group">
        <span class="relative z-10 text-blue text-nowrap"> Talk To Us </span>
        <div class="absolute inset-0 bg-gradient-to-l from-[#ab00ff] via-[#7000eb] to-[#00c8eb] rounded-lg p-[1px]">
          <div class="h-full w-full bg-white rounded-lg"></div>
        </div>
      </button>
    </div>
  </div>
  <script>
    // Cycle active consulting card every 3 seconds
    (() => {
      const cards = document.querySelectorAll("#consulting-cards > div.card");
      let activeIndex = 0;

      function updateCards() {
        cards.forEach((card, i) => {
          card.classList.remove("gradient-border", "rounded-md");
          card.classList.remove("bg-zinc-50");
          if (i === activeIndex) {
            card.classList.add("gradient-border", "rounded-md");
          }
          if (activeIndex === 0 && i === cards.length - 1) {
            cards[i].classList.add("bg-zinc-50");
          } else if (activeIndex === 1 && i === 0) {
            cards[i].classList.add("bg-zinc-50");
          } else if (activeIndex === 2 && i === 1) {
            cards[i].classList.add("bg-zinc-50");
          }
        });
      }

      updateCards();

      setInterval(() => {
        activeIndex = (activeIndex + 1) % cards.length;
        updateCards();
      }, 3000);
    })();
  </script>
</section>

<!-- LATEST CASE STUDY SECTION -->
<section class="w-full px-5 lg:px-10 bg-cover relative">
  <div class="container">
    <div class="flex flex-col items-end justify-between mt-6 mb-3 w-full">
      <div class="w-full flex flex-col gap-5 items-start">
        <!-- Section Heading -->
        <div class="text-md font-semibold text-[#656565]">CASE STUDY</div>
        <div class="flex flex-col gap-5 lg:gap-0 lg:flex-row justify-between w-full">
          <h2
            class="w-full lg:w-11/12 text-4xl gap-3 font-bold text-black1 font-urbanist leading-snug tracking-[0.5px]">
            Real-World Case Studies of 
            <span class="text-gradient">AI-Driven Enterprise Communication
            </span>
          </h2>
          <div class="flex gap-2 mt-8 md:mt-0">
            <!-- Prev -->
            <svg id="custom-cs-prev" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50"
              fill="none" class="cursor-pointer">
              <mask id="mask-prev" maskUnits="userSpaceOnUse" x="1" y="1" width="48" height="48">
                <path
                  d="M25 4.17C13.49 4.17 4.17 13.49 4.17 25C4.17 36.51 13.49 45.83 25 45.83C36.51 45.83 45.83 36.51 45.83 25C45.83 13.49 36.51 4.17 25 4.17Z"
                  fill="white" stroke="white" stroke-width="5.33" stroke-linejoin="round" />
                <path d="M28.13 15.63L18.75 25L28.13 34.38" stroke="black" stroke-width="5.33" stroke-linecap="round"
                  stroke-linejoin="round" />
              </mask>
              <g mask="url(#mask-prev)">
                <path d="M50 50H0V0H50V50Z" fill="url(#paint-prev)" />
              </g>
              <defs>
                <linearGradient id="paint-prev" x1="50" y1="25" x2="-7.5" y2="25" gradientUnits="userSpaceOnUse">
                  <stop stop-color="#7C3BAF" />
                  <stop offset="1" stop-color="#E61C42" />
                </linearGradient>
              </defs>
            </svg>
            <!-- Next -->
            <svg id="custom-cs-next" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50"
              fill="none" class="cursor-pointer">
              <mask id="mask-next" maskUnits="userSpaceOnUse" x="1" y="1" width="48" height="48">
                <path
                  d="M25 45.83C36.51 45.83 45.83 36.51 45.83 25C45.83 13.49 36.51 4.17 25 4.17C13.49 4.17 4.17 13.49 4.17 25C4.17 36.51 13.49 45.83 25 45.83Z"
                  fill="white" stroke="white" stroke-width="5.33" stroke-linejoin="round" />
                <path d="M21.88 34.38L31.25 25L21.88 15.63" stroke="black" stroke-width="5.33" stroke-linecap="round"
                  stroke-linejoin="round" />
              </mask>
              <g mask="url(#mask-next)">
                <path d="M0 0H50V50H0V0Z" fill="url(#paint-next)" />
              </g>
              <defs>
                <linearGradient id="paint-next" x1="5" y1="31" x2="62" y2="32" gradientUnits="userSpaceOnUse">
                  <stop stop-color="#7C3BAF" />
                  <stop offset="1" stop-color="#E61C42" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
        <!-- Slider with custom arrows -->
        <div class="flex justify-evenly items-center gap-2 md:gap-5 w-full">
          <!-- Swiper Wrapper -->
          <div class="swiper swiper-case-study w-full">
            <div class="swiper-wrapper bg-[#F2F7FF]">
              <!-- Slide 1 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide">
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]">
                    <h3 class="text-xl md:text-3xl font-semibold">
                      Streamlining Cross-Time-Zone Collaboration for Global Tech Firm
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        A multinational tech company experienced communication delays and inefficiencies across its global teams, which impacted project delivery timelines and overall productivity. Intellivon implemented an AI-powered unified communication system with real-time translation, intelligent meeting transcription, and automated task tracking.
                      </p>
                      <p class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm">
                        A multinational tech company experienced communication delays and inefficiencies across its global teams, which impacted project delivery timelines and overall productivity. Intellivon implemented an AI-powered unified communication system with real-time translation, intelligent meeting transcription, and automated task tracking.
                      </p>
                      <button class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden">
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      <span class="xl:text-xl font-semibold">35%</span>
                      <span> improvement in project delivery speed</span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">40%</span>
                      <span> reduction in cross-team coordination time</span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">50%</span>
                      <span> acceleration in go-to-market cycles</span>
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a href="https://intellivon.com/ai-strategy-call-booking-confirmation/" target="_blank">
                    <div class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button">
                      Explore more
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white" />
                      </svg>
                    </div>
                  </a>
                </div>
                <div class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl">
                  <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-1.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl" />
                </div>
              </div>
              <!-- Slide 2 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide">
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]">
                    <h3 class="text-xl md:text-3xl font-semibold">
                      Optimizing Supply Chain Communication for Logistics Leaders
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        A global logistics provider struggled with fragmented communication, causing delays among suppliers, carriers, and warehouses. Intellivon deployed an AI-driven communication platform with real-time updates, automated alerts, and multilingual support.
                      </p>
                      <p class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm">
                        A global logistics provider struggled with fragmented communication, causing delays among suppliers, carriers, and warehouses. Intellivon deployed an AI-driven communication platform with real-time updates, automated alerts, and multilingual support.
                      </p>
                      <button class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden">
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      <span class="xl:text-xl font-semibold">30%</span>
                      <span>
                          improvement in delivery times
                      </span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">20%</span>
                      <span>
                           reduction in operational costs
                      </span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">45%</span>
                      <span> increase in supply chain responsiveness</span>
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a href="https://intellivon.com/ai-strategy-call-booking-confirmation/" target="_blank">
                    <div class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button">
                      Explore more
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white" />
                      </svg>
                    </div>
                  </a>
                </div>
                <div class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl">
                  <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-2.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl" />
                </div>
              </div>
              <!-- Slide 3 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide">
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]">
                    <h3 class="text-xl md:text-3xl font-semibold">
                      Enhancing Compliance and Workflow for Financial Services Enterprise
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        A large financial institution needed to streamline communication around compliance workflows and risk management. Intellivon integrated AI-powered chatbots and document automation tools into their communication system.
                      </p>
                      <p class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm">
                        A large financial institution needed to streamline communication around compliance workflows and risk management. Intellivon integrated AI-powered chatbots and document automation tools into their communication system.
                      </p>
                      <button class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden">
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      <span class="xl:text-xl font-semibold">25% </span>
                      <span>reduction in compliance-related process time                        
                      </span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">40%</span>
                      <span>
                         improvement in audit preparation efficiency 
                      </span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">50% </span>
                      <span>accelerated regulatory reporting</span>
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a href="https://intellivon.com/ai-strategy-call-booking-confirmation/" target="_blank">
                    <div class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button">
                      Explore more
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white" />
                      </svg>
                    </div>
                  </a>
                </div>
                <div class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl">
                  <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-3.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl" />
                </div>
              </div>
              <!-- Slide 4 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide">
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]">
                    <h3 class="text-xl md:text-3xl font-semibold">
                      Boosting Sales Team Productivity for Retail Chain
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        A retail enterprise’s sales teams across regions faced delays in accessing product information and customer insights. Intellivon implemented an AI-enabled communication system with intelligent knowledge management and real-time query resolution.
                      </p>
                      <p class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm">
                        A retail enterprise’s sales teams across regions faced delays in accessing product information and customer insights. Intellivon implemented an AI-enabled communication system with intelligent knowledge management and real-time query resolution.
                      </p>
                      <button class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden">
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      <span class="xl:text-xl font-semibold">30% </span>
                      <span>reduction in sales cycle duration</span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">35%</span>
                      <span> improvement in product launch coordination                        
                      </span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">45% </span>
                      <span>enhancement in market responsiveness</span>
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a href="https://intellivon.com/ai-strategy-call-booking-confirmation/" target="_blank">
                    <div class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button">
                      Explore more
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white" />
                      </svg>
                    </div>
                  </a>
                </div>
                <div class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl">
                  <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-4.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl" />
                </div>
              </div>
              <!-- Slide 5 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide">
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]">
                    <h3 class="text-xl md:text-3xl font-semibold">
                      Accelerating Patient Coordination for Healthcare Provider
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        A healthcare network is necessary to enhance communication among care teams, administrative staff, and patients. Intellivon delivered an AI-powered communication platform with multilingual support, automated reminders, and real-time collaboration tools.
                      </p>
                      <p class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm">
                        A healthcare network is necessary to enhance communication among care teams, administrative staff, and patients. Intellivon delivered an AI-powered communication platform with multilingual support, automated reminders, and real-time collaboration tools.
                      </p>
                      <button class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden">
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      <span class="xl:text-xl font-semibold">40%</span>
                      <span> increase in patient scheduling efficiency</span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">35%</span>
                      <span>
                         reduction in interdepartmental communication delays
                      </span>
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">60%</span>
                      <span>improved resource utilization</span>
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a href="https://intellivon.com/ai-strategy-call-booking-confirmation/" target="_blank">
                    <div class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button">
                      Explore more
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white" />
                      </svg>
                    </div>
                  </a>
                </div>
                <div class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl">
                  <img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-5.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Dots -->
      <div id="case-study-dots" class="flex flex-wrap gap-2 items-center justify-center mt-5 mx-auto">
        <div class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 70px; opacity: 1"></div>
        <div class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 28px; opacity: 0.5"></div>
        <div class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 20px; opacity: 0.5"></div>
        <div class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 20px; opacity: 0.5"></div>
        <div class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 20px; opacity: 0.5"></div>
      </div>
      <!-- Button -->
      <a class="m-auto my-5 rounded-full bg-white flex gap-3 w-fit p-3 z-20 outline-gradient"
        href="https://intellivon.com/portfolio/" target="_blank">
        <div>View more Projects</div>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
          <path fill-rule="evenodd" clip-rule="evenodd"
            d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
            fill="url(#paint0_linear_2_494)" />
          <defs>
            <linearGradient id="paint0_linear_2_494" x1="6.5" y1="7" x2="22" y2="13" gradientUnits="userSpaceOnUse">
              <stop stop-color="#7C3BAF" />
              <stop offset="1" stop-color="#E61C42" />
            </linearGradient>
          </defs>
        </svg>
      </a>
    </div>
  </div>

  <!-- Custom Swiper Logic -->
  <script>
    const csSwiper = new Swiper(".swiper-case-study", {
      slidesPerView: 1,
      slidesPerGroup: 1,
      spaceBetween: 10,
      loop: true,
      autoplay: {
        delay: 3000, //  3 seconds
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: "#custom-cs-next",
        prevEl: "#custom-cs-prev",
      },
      centeredSlides: false,
      centeredSlidesBounds: true,
      breakpoints: {
        0: {
          slidesPerView: 1,
          slidesPerGroup: 1,
        },
        768: {
          slidesPerView: 1,
          slidesPerGroup: 1,
        },
        1024: {
          slidesPerView: 1,
          slidesPerGroup: 1,
        },
      },
    });

    // Pause the slider on hover
    const slides = document.querySelectorAll(".swiper-slide");
    slides.forEach((slide) => {
      slide.addEventListener("mouseenter", () => {
        csSwiper.autoplay.stop(); // Stop autoplay on hover
      });

      slide.addEventListener("mouseleave", () => {
        csSwiper.autoplay.start(); // Resume autoplay when hover is removed
      });
    });

    // Update the active dot on slide change
    csSwiper.on("slideChange", function () {
      const dots = document.querySelectorAll("#case-study-dots div");
      dots.forEach((dot, index) => {
        if (index === csSwiper.realIndex) {
          dot.style.width = "70px";
          dot.style.opacity = "1";
        } else {
          dot.style.width = "28px";
          dot.style.opacity = "0.5";
        }
      });
    });
  </script>
</section>

<!-- USECASES -->
<section class="w-full px-5 lg:px-10 py-14 lg:py-20 bg-[#F2F7FF] relative overflow-hidden">
  <div class="container flex flex-col gap-5 items-center">
    <!-- Heading -->
    <div class="w-full">
      <div class="text-md font-semibold text-[#656565]">USECASES</div>
      <h2 class="w-full lg:w-11/12 text-4xl gap-3 font-bold text-black1 font-urbanist leading-snug tracking-[0.5px]">
        Real Use Cases Of Our AI-Driven Enterprise  
        <span class="text-gradient">Communication Services</span>
      </h2>
    </div>

    <!-- Slider with custom arrows -->
    <div class="flex justify-evenly items-center gap-2 md:gap-5 w-full">
      <!-- Prev Button -->
      <div class="cursor-pointer" id="custom-prev">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 30 30" fill="none"
          class="rotate-180">
          <rect width="30" height="30" rx="15" fill="url(#paint0_linear_217_524)" />
          <path d="M12.5 8.75L18.75 15L12.5 21.25" stroke="white" stroke-width="3" stroke-linecap="round"
            stroke-linejoin="round" />
          <defs>
            <linearGradient id="paint0_linear_217_524" x1="8.5" y1="4" x2="25.5" y2="30" gradientUnits="userSpaceOnUse">
              <stop stop-color="#7C3BAF" />
              <stop offset="1" stop-color="#E61C42" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <!-- Swiper Wrapper -->
      <div class="swiper swiper-usecases w-full">
        <div class="swiper-wrapper">
          <!-- CARD 1 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]">
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  Intelligent Chatbots
                </h3>
              </div>
              <p class="text-center md:text-start">
                Deployed in HR and IT, AI chatbots handle routine queries, allowing staff to focus on complex issues. Advanced bots escalate, analyze sentiment, and learn from inputs.
              </p>
            </div>
          </div>

          <!-- CARD 2 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]">
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  Voice Assistants
                </h3>
              </div>
              <p class="text-center md:text-start">
                Voice-activated commands streamline tasks such as scheduling meetings, setting reminders, and searching documents, thereby reducing reliance on manual inputs and enhancing employee efficiency.
              </p>
            </div>
          </div>

          <!-- CARD 3 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]">
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  AI-Powered Transcription & Translation
                </h3>
              </div>
              <p class="text-center md:text-start">
                Real-time transcription ensures accurate meeting documentation, while integrated translation tools enable seamless multilingual communication for global teams.
              </p>
            </div>
          </div>
          <!-- CARD 4 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]">
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  Sentiment Analysis
                </h3>
              </div>
              <p class="text-center md:text-start">
                AI analyzes employee communications to track mood and tone, enabling HR teams to monitor morale and intervene when necessary to enhance workplace culture.
              </p>
            </div>
          </div>

          <!-- CARD 5 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]">
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  Smart Meeting Scheduling
                </h3>
              </div>
              <p class="text-center md:text-start">
                AI detects calendar conflicts, suggests optimal meeting times, and generates concise post-meeting summaries with actionable points to improve collaboration and productivity.
              </p>
            </div>
          </div>

        </div>
      </div>

      <!-- Next Button -->
      <div class="cursor-pointer" id="custom-next">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 30 30" fill="none">
          <rect width="30" height="30" rx="15" fill="url(#paint0_linear_217_524)" />
          <path d="M12.5 8.75L18.75 15L12.5 21.25" stroke="white" stroke-width="3" stroke-linecap="round"
            stroke-linejoin="round" />
          <defs>
            <linearGradient id="paint0_linear_217_524" x1="8.5" y1="4" x2="25.5" y2="30" gradientUnits="userSpaceOnUse">
              <stop stop-color="#7C3BAF" />
              <stop offset="1" stop-color="#E61C42" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  </div>

  <!-- Background Decoration (same as before) -->
  <div class="absolute bottom-0 right-0 w-[320px] h-[421px] overflow-hidden pointer-events-none">
    <!-- Your SVG here -->
  </div>
  <div class="absolute bottom-2 left-[5%] w-[1257px] h-[421px] overflow-hidden pointer-events-none">
    <!-- Your SVG here -->
  </div>

  <!-- Custom Swiper Logic -->
  <script>
    const swiper = new Swiper(".swiper-usecases", {
      slidesPerView: 3,
      slidesPerGroup: 3,
      spaceBetween: 20,
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: "#custom-next",
        prevEl: "#custom-prev",
      },
      centeredSlides: false,
      centeredSlidesBounds: true, // ✅ Key to center-align last group if fewer than 3
      breakpoints: {
        0: {
          slidesPerView: 1,
          slidesPerGroup: 1,
        },
        768: {
          slidesPerView: 2,
          slidesPerGroup: 2,
        },
        1024: {
          slidesPerView: 3,
          slidesPerGroup: 1,
        },
      },
    });
  </script>
</section>

<!-- WHY CHOOSE US -->
<section class="py-24 w-full bg-cover px-5 lg:px-10 relative overflow-hidden">
  <div class="container">
    <div class="flex items-end justify-between mt-6 mb-3 w-full">
      <div class="w-full">
        <div class="w-full flex flex-col gap-5 items-start">
          <div class="text-md font-semibold text-[#656565]">WHY CHOOSE US</div>
          <div class="flex flex-col gap-5 lg:gap-0 lg:flex-row justify-between">
            <h2 class="w-full lg:w-7/12 text-4xl flex-wrap gap-3 flex items-center font-bold text-black1 font-urbanist">
              Unlock the Power of 
              <span class="text-gradient">AI Enterprise Communication with Intellivon</span>
            </h2>
            <a href="https://intellivon.com/ai-strategy-call-booking-confirmation/" target="_blank">
              <div>
                <button type="button"
                  class="relative px-3 py-3 text-white font-medium rounded-full bg-white overflow-hidden group">
                  <span
                    class="relative z-10 text-blue text-nowrap text-sm lg:text-md items-center lg:items-normal flex gap-2">
                    Know More About Our Capabilities
                    <img
                      src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/know-more-capabilities-arrow.svg" />
                  </span>
                  <div
                    class="absolute inset-0 bg-gradient-to-l from-[#ab00ff] via-[#7000eb] to-[#00c8eb] rounded-full p-[1px]">
                    <div class="h-full w-full bg-white rounded-full"></div>
                  </div>
                </button>
              </div>
            </a>
          </div>
          <p class="text-grey1 text-base font-medium">
            Our scalable AI solutions enhance productivity, automate routine tasks, and empower your teams to focus on strategic growth.
          </p>
        </div>
      </div>
    </div>
    <div class="mt-16 grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
      <!-- Card 1 -->
      <div class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10">
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center">
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Seamless Legacy Integration
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800">
            <!-- SVG Icon -->

            <p class="text-sm">
              Our AI solutions integrate seamlessly with your existing communication infrastructure, enhancing what you already have without disruption so you get the most out of your current technology.
            </p>
          </div>
        </div>
      </div>
      <!-- Card 2 -->
      <div class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10">
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center">
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Advanced Communication Tech
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800">
            <!-- SVG Icon -->

            <p class="text-sm">
              We bring the latest in AI, from emotional intelligence to AR/VR integration, keeping your enterprise at the forefront of communication innovation.
            </p>
          </div>
        </div>
      </div>
      <!-- Card 3 -->
      <div class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10">
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center">
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">Multilingual Collaboration</h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800">
            <!-- SVG Icon -->

            <p class="text-sm">
              Break down language barriers with accurate, real-time translations, enabling smooth collaboration among global teams across different regions and departments.
            </p>
          </div>
        </div>
      </div>
      <!-- Card 4 -->
      <div class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10">
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center">
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Generative Meeting Docs
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800">
            <!-- SVG Icon -->

            <p class="text-sm">
              Convert meeting transcripts into actionable summaries and automatically generate follow-up tasks, saving time and boosting productivity across your organization.
            </p>
          </div>
        </div>
      </div>

      <!-- Card 5 -->
      <div class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10">
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center">
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              AR/VR Communication Spaces
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800">
            <!-- SVG Icon -->

            <p class="text-sm">
              Enhance collaboration with AR/VR-supported virtual meeting spaces, creating a more engaging environment for remote and distributed teams.
            </p>
          </div>
        </div>
      </div>

      <!-- Card 6 -->
      <div class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10">
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center">
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Modular Cloud System
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800">
            <!-- SVG Icon -->

            <p class="text-sm">
              Our modular cloud-based system grows with your business, providing enterprise-grade security and reliability while adapting to your evolving needs.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Background Decoration -->
  <div class="absolute right-0 top-0 w-[468px] h-[634px] overflow-hidden pointer-events-none">
    <svg xmlns="http://www.w3.org/2000/svg" width="468" height="634" viewBox="0 0 468 634" fill="none">
      <g filter="url(#filter0_f_47_15221)">
        <path
          d="M564 197C564 126.86 507.14 70 437 70C366.86 70 310 126.86 310 197C310 267.14 366.86 324 437 324C507.14 324 564 267.14 564 197Z"
          fill="#7C3BAF" />
      </g>
      <defs>
        <filter id="filter0_f_47_15221" x="0.200012" y="-239.8" width="873.6" height="873.6"
          filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_47_15221" />
        </filter>
      </defs>
    </svg>
  </div>
  <div class="absolute left-0 top-[30%] w-[407px] h-[823px] overflow-hidden pointer-events-none">
    <svg xmlns="http://www.w3.org/2000/svg" width="407" height="823" viewBox="0 0 407 823" fill="none">
      <g filter="url(#filter0_f_47_15222)">
        <path
          d="M97 437C97 366.86 40.1402 310 -30 310C-100.14 310 -157 366.86 -157 437C-157 507.14 -100.14 564 -30 564C40.1402 564 97 507.14 97 437Z"
          fill="#E61C42" fill-opacity="0.6" />
      </g>
      <defs>
        <filter id="filter0_f_47_15222" x="-466.8" y="0.200012" width="873.6" height="873.6"
          filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_47_15222" />
        </filter>
      </defs>
    </svg>
  </div>
  <div class="hidden lg:block absolute left-[30%] top-[30%] w-[821px] h-[744px] overflow-hidden pointer-events-none">
    <svg xmlns="http://www.w3.org/2000/svg" width="821" height="744" viewBox="0 0 821 744" fill="none" class="w-max-20">
      <g filter="url(#filter0_f_47_15226)">
        <path
          d="M511 410.5C511 354.995 466.005 310 410.5 310C354.995 310 310 354.995 310 410.5C310 466.005 354.995 511 410.5 511C466.005 511 511 466.005 511 410.5Z"
          fill="#E61C42" />
      </g>
      <defs>
        <filter id="filter0_f_47_15226" x="0.200012" y="0.200012" width="820.6" height="820.6"
          filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_47_15226" />
        </filter>
      </defs>
    </svg>
  </div>
</section>

<!-- HOME COUNTS -->
<div class="bg-gradient-to-l from-[#E61C42] to-[#61268F] lg:py-12 py-10 relative max-w-full overflow-hidden">
  <div class="container grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
    <!-- Count Item 1 -->
    <div class="flex flex-col items-center px-5">
      <h3 class="text-medium font-bold text-white font-urbanist my-3 text-center">
        500+
      </h3>
      <h3 class="text-xl font-normal text-white text-center">
        Successful AI-driven projects
      </h3>
    </div>
    <!-- Count Item 2 -->
    <div class="flex flex-col items-center px-5">
      <h3 class="text-medium font-bold text-white font-urbanist my-3 text-center">
        11+
      </h3>
      <h3 class="text-xl font-normal text-white text-center">
        Year of expertise in delivering AI Solutions
      </h3>
    </div>
    <!-- Count Item 3 -->
    <div class="flex flex-col items-center px-5">
      <h3 class="text-medium font-bold text-white font-urbanist my-3 text-center">
        40+
      </h3>
      <h3 class="text-xl font-normal text-white text-center">
        AI, ML, and data tools mastered
      </h3>
    </div>
    <!-- Count Item 4 -->
    <div class="flex flex-col items-center px-10">
      <h3 class="text-medium font-bold text-white font-urbanist my-3 text-center">
        200+
      </h3>
      <h3 class="text-xl font-normal text-white text-center px-5">
        Dedicated AI experts
      </h3>
    </div>
  </div>
  <div class="absolute top-0 left-0 max-w-[288px] max-h-[187px] overflow-hidden pointer-events-none">
    <svg xmlns="http://www.w3.org/2000/svg" width="288" height="187" viewBox="0 0 288 187" fill="none">
      <path opacity="0.6"
        d="M-6.00009 77.3586C14.732 155.567 96.0211 201.874 175.564 180.788C255.107 159.702 302.783 79.2084 282.051 0.999952"
        stroke="#9A9A9A" />
    </svg>
  </div>
  <div class="absolute bottom-0 left-[50%] max-w-[315px] max-h-[137px] overflow-hidden pointer-events-none">
    <svg xmlns="http://www.w3.org/2000/svg" width="315" height="137" viewBox="0 0 315 137" fill="none">
      <path opacity="0.4" d="M313.975 150.186C313.975 67.7929 243.913 1 157.487 1C71.0618 1 1 67.7929 1 150.186"
        stroke="#9A9A9A" />
    </svg>
  </div>
  <div class="absolute top-0 right-0 max-w-[300px] max-h-[190px] overflow-hidden pointer-events-none">
    <svg xmlns="http://www.w3.org/2000/svg" width="300" height="190" viewBox="0 0 300 190" fill="none">
      <path opacity="0.5"
        d="M5.38462 0.521899C-15.527 80.374 33.3583 162.348 114.573 183.617C195.788 204.885 278.578 157.394 299.489 77.5419"
        stroke="#9A9A9A" />
    </svg>
  </div>
</div>

<!-- POWERED TECHNOLOGIES -->
<section class="bg-powered py-16 lg:py-24 bg-cover bg-no-repeat px-5 lg:px-10">
  <div class="container">
    <!-- Heading -->
    <div class="w-full flex flex-col gap-3 items-start">
      <div class="text-md font-semibold text-[#656565]">TECHNOLOGY WE USE</div>
      <h2 class="text-4xl font-bold text-black1 font-urbanist leading-snug tracking-[0.5px] w-full md:gap-3">
        Our AI Enterprise Communication  
        <span class="text-gradient"> Tech Stack</span>
      </h2>
      <div class="w-full flex flex-col lg:flex-row justify-between">
        <p class="capitalize mb-4 md:mb-0 text-base font-medium text-grey1 mt-2 md:w-8/12 tracking-[0.25px] pr-5">
          We utilize a robust AI technology stack to power our communication solutions, ensuring seamless integration, real-time responsiveness, and enhanced collaboration for enterprises of all sizes.
        </p>
        <!-- Buttons -->
        <div class="flex gap-2 mt-8 lg:mt-0">
          <div class="cursor-pointer" id="custom-tech-prev">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 30 30" fill="none"
              class="rotate-180">
              <rect width="30" height="30" rx="15" fill="url(#paint0_linear_217_524)" />
              <path d="M12.5 8.75L18.75 15L12.5 21.25" stroke="white" stroke-width="3" stroke-linecap="round"
                stroke-linejoin="round" />
              <defs>
                <linearGradient id="paint0_linear_217_524" x1="8.5" y1="4" x2="25.5" y2="30"
                  gradientUnits="userSpaceOnUse">
                  <stop stop-color="#7C3BAF" />
                  <stop offset="1" stop-color="#E61C42" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <div class="cursor-pointer" id="custom-tech-next">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 30 30" fill="none">
              <rect width="30" height="30" rx="15" fill="url(#paint0_linear_217_524)" />
              <path d="M12.5 8.75L18.75 15L12.5 21.25" stroke="white" stroke-width="3" stroke-linecap="round"
                stroke-linejoin="round" />
              <defs>
                <linearGradient id="paint0_linear_217_524" x1="8.5" y1="4" x2="25.5" y2="30"
                  gradientUnits="userSpaceOnUse">
                  <stop stop-color="#7C3BAF" />
                  <stop offset="1" stop-color="#E61C42" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>
    </div>
    <!-- Swiper Carousel -->
    <div class="mt-10">
      <!-- Custom Navigation Buttons outside the swiper box -->
      <div class="swiper techSwiper">
        <div class="swiper-wrapper min-h-auto">
          <!-- Slide 1:  -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Natural Language Processing (NLP) & Understanding
              </h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Repeat these card blocks -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    SpaCy
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    NLTK
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Hugging Face Transformers
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Cloud Natural Language
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    IBM Watson NLP
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Speech API
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Microsoft Azure Speech
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Deepgram
                  </h4>
                </div>                


              </div>
            </div>
          </div>
          <!-- Slide 2: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Machine Learning & AI Frameworks
              </h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    TensorFlow
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    PyTorch
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Keras
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    OpenAI
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google AI
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    IBM Watson
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Dialogflow
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Rasa
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Microsoft Bot Framework
                  </h4>
                </div>


              </div>
            </div>
          </div>
          <!-- Slide 3: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">Real-Time Communication & Collaboration</h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    WebRTC
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    SignalR
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Socket.io
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Twilio
                  </h4>
                </div>

              </div>
            </div>
          </div>
          <!-- Slide 4: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Cloud Infrastructure & Scalability
              </h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    AWS
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Cloud
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Microsoft Azure
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Docker
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Kubernetes
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    AWS Lambda
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Cloud Functions
                  </h4>
                </div>


              </div>
            </div>
          </div>
          <!-- Slide 5: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Data Storage & Management
              </h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    PostgreSQL
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    MySQL
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    MongoDB
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Cassandra
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Amazon Redshift
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google BigQuery
                  </h4>
                </div>                

              </div>
            </div>
          </div>
          <!-- Slide 6: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">Multilingual Support & Translation</h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Cloud Translation
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Microsoft Translator
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Amazon Translate
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Cloud Text-to-Speech
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Amazon Polly
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Speech-to-Text
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Microsoft Azure Cognitive Services
                  </h4>
                </div>

              </div>
            </div>
          </div>

          <!-- Slide 7: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">Security & Compliance</h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    AES-256
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    TLS 1.2/1.3
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    AWS IAM
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Cloud IAM
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Azure Active Directory
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    HIPAA
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    GDPR
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    SOC 2
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    PCI DSS
                  </h4>
                </div>

              </div>
            </div>
          </div>

          <!-- Slide 8: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">Integration & Workflow Automation</h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Zapier
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Integromat
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Microsoft Power Automate
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Salesforce
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    HubSpot
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Zoho CRM
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    SAP
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Microsoft Dynamics 365
                  </h4>
                </div>

              </div>
            </div>
          </div>

          <!-- Slide 9: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">Multilingual Support & Translation</h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Tableau
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Power BI
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Data Studio
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Apache Kafka
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Apache Spark
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    IBM Watson Analytics
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google AI Platform
                  </h4>
                </div>

              </div>
            </div>
          </div>

          <!-- Slide 10: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">User Interface & Experience</h3>
              <div class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto">
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    React.js
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Angular
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Vue.js
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Material-UI
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Ant Design
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Figma
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Sketch
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- svg -->

                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Adobe XD
                  </h4>
                </div>

              </div>
            </div>
          </div>



        </div>
      </div>
    </div>
  </div>
  <!-- Powered Technologies Script -->
  <script>
    document.addEventListener("DOMContentLoaded", () => {
      // Initialize Swiper 11 with navigation disabled (we'll use custom buttons)
      const swiper = new Swiper(".techSwiper", {
        loop: true,
        speed: 200,
        autoplay: {
          delay: 2000,
          disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: false, // disable default arrows
      });

      // Attach event listeners to custom buttons
      const prevBtn = document.getElementById("custom-tech-prev");
      const nextBtn = document.getElementById("custom-tech-next");

      prevBtn.addEventListener("click", () => swiper.slidePrev());
      nextBtn.addEventListener("click", () => swiper.slideNext());
    });
  </script>
</section>

<!-- TESTIMONIALS SECTION -->
<section>
  <div class="bg-white bg-cover relative overflow-hidden px-5 lg:px-10 py-12">
    <!-- Background Decoration -->
    <div class="absolute left-0 top-[10%] max-w-[403px] max-h-fit verflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="403" height="576" viewBox="0 0 403 576" fill="none">
        <g filter="url(#filter0_f_2_589)">
          <path
            d="M203 339.5C203 418.201 138.977 482 60 482C-18.9767 482 -83 418.201 -83 339.5C-83 260.799 -18.9767 197 60 197C138.977 197 203 260.799 203 339.5Z"
            fill="#E61C42" fill-opacity="0.2" />
        </g>
        <defs>
          <filter id="filter0_f_2_589" x="-283" y="-3" width="686" height="685" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="100" result="effect1_foregroundBlur_2_589" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="absolute left-[20%] top-[10%] max-w-[686px] max-h-[534px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="686" height="534" viewBox="0 0 686 534" fill="none">
        <g filter="url(#filter0_f_2_591)">
          <path
            d="M486 342.5C486 421.201 421.977 485 343 485C264.023 485 200 421.201 200 342.5C200 263.799 264.023 200 343 200C421.977 200 486 263.799 486 342.5Z"
            fill="#7C3BAF" fill-opacity="0.3" />
        </g>
        <defs>
          <filter id="filter0_f_2_591" x="0" y="0" width="686" height="685" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="100" result="effect1_foregroundBlur_2_591" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="absolute left-[25%] top-[10%] max-w-[686px] max-h-[534px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="686" height="576" viewBox="0 0 686 576" fill="none">
        <g filter="url(#filter0_f_2_590)">
          <path
            d="M486 316.5C486 395.201 421.977 459 343 459C264.023 459 200 395.201 200 316.5C200 237.799 264.023 174 343 174C421.977 174 486 237.799 486 316.5Z"
            fill="#E61C42" fill-opacity="0.3" />
        </g>
        <defs>
          <filter id="filter0_f_2_590" x="0" y="-26" width="686" height="685" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="100" result="effect1_foregroundBlur_2_590" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="absolute right-0 top-24 max-w-[449px] max-h-fit overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="449" height="556" viewBox="0 0 449 556" fill="none">
        <g filter="url(#filter0_f_2_592)">
          <path
            d="M486 342.5C486 421.201 421.977 485 343 485C264.023 485 200 421.201 200 342.5C200 263.799 264.023 200 343 200C421.977 200 486 263.799 486 342.5Z"
            fill="#7C3BAF" fill-opacity="0.4" />
        </g>
        <defs>
          <filter id="filter0_f_2_592" x="0" y="0" width="686" height="685" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="100" result="effect1_foregroundBlur_2_592" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="container">
      <div class="flex items-end justify-between mt-6 mb-3">
        <div class="w-full flex flex-col gap-5">
          <!-- Section Heading -->
          <div class="text-md font-semibold text-[#656565]">
            TESTIMONIAL SECTION
          </div>
          <div class="flex flex-col gap-5 lg:gap-0 lg:flex-row justify-between w-full">
            <h2
              class="w-full lg:w-11/12 text-4xl gap-3 font-bold text-black1 font-urbanist leading-snug tracking-[0.5px]">
              <span class="text-gradient">
                What Our Clients Say About Us
              </span>
            </h2>
            <div class="flex gap-2 z-50 mt-8 lg:mt-0">
              <!-- Prev -->
              <svg id="testimonial-prev" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50"
                fill="none" class="cursor-pointer">
                <mask id="mask-prev" maskUnits="userSpaceOnUse" x="1" y="1" width="48" height="48">
                  <path
                    d="M25 4.17C13.49 4.17 4.17 13.49 4.17 25C4.17 36.51 13.49 45.83 25 45.83C36.51 45.83 45.83 36.51 45.83 25C45.83 13.49 36.51 4.17 25 4.17Z"
                    fill="white" stroke="white" stroke-width="5.33" stroke-linejoin="round" />
                  <path d="M28.13 15.63L18.75 25L28.13 34.38" stroke="black" stroke-width="5.33" stroke-linecap="round"
                    stroke-linejoin="round" />
                </mask>
                <g mask="url(#mask-prev)">
                  <path d="M50 50H0V0H50V50Z" fill="url(#paint-prev)" />
                </g>
                <defs>
                  <linearGradient id="paint-prev" x1="50" y1="25" x2="-7.5" y2="25" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#7C3BAF" />
                    <stop offset="1" stop-color="#E61C42" />
                  </linearGradient>
                </defs>
              </svg>
              <!-- Next -->
              <svg id="testimonial-next" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50"
                fill="none" class="cursor-pointer">
                <mask id="mask-next" maskUnits="userSpaceOnUse" x="1" y="1" width="48" height="48">
                  <path
                    d="M25 45.83C36.51 45.83 45.83 36.51 45.83 25C45.83 13.49 36.51 4.17 25 4.17C13.49 4.17 4.17 13.49 4.17 25C4.17 36.51 13.49 45.83 25 45.83Z"
                    fill="white" stroke="white" stroke-width="5.33" stroke-linejoin="round" />
                  <path d="M21.88 34.38L31.25 25L21.88 15.63" stroke="black" stroke-width="5.33" stroke-linecap="round"
                    stroke-linejoin="round" />
                </mask>
                <g mask="url(#mask-next)">
                  <path d="M0 0H50V50H0V0Z" fill="url(#paint-next)" />
                </g>
                <defs>
                  <linearGradient id="paint-next" x1="5" y1="31" x2="62" y2="32" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#7C3BAF" />
                    <stop offset="1" stop-color="#E61C42" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div class="mt-16 grid grid-cols-1 lg:grid-cols-2 gap-14 lg:gap-10">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5 order-2 lg:order-1">
          <div class="common-whitebox2 p-6 rounded-lg shadow-lg h-44">
            <h3 class="text-5xl font-normal font-urbanist text-gradient2">
              50
              <span class="text-2xl"> % </span>
            </h3>
            <p class="text-xl font-medium text-black1 font-urbanist mt-8 pr-5">
              Faster modernization cycle
            </p>
          </div>
          <div class="common-whitebox2 p-6 rounded-lg shadow-lg h-44">
            <h3 class="text-5xl font-normal font-urbanist text-gradient2">
              30 - 40
              <span class="text-2xl"> % </span>
            </h3>
            <p class="text-xl font-medium text-black1 font-urbanist mt-8">
              Lower engineering costs
            </p>
          </div>
          <div class="common-whitebox2 p-6 rounded-lg shadow-lg h-44">
            <h3 class="text-5xl font-normal font-urbanist text-gradient2">
              80
              <span class="text-2xl"> % </span>
            </h3>
            <p class="text-xl font-medium text-black1 font-urbanist mt-8">
              Fewer bugs and reworks
            </p>
          </div>
          <div class="common-whitebox2 p-6 rounded-lg shadow-lg h-44">
            <h3 class="text-5xl font-normal font-urbanist text-gradient2">
              50
              <span class="text-2xl"> % </span>
            </h3>
            <p class="text-xl font-medium text-black1 font-urbanist mt-8 pr-5">
              Faster launch timelines
            </p>
          </div>
        </div>
        <!-- Testimonial Slider -->
        <div id="testimonial-slider" class="overflow-hidden relative w-full max-w-full order-1 lg:order-2 z-20">
          <div id="testimonial-track" class="flex transition-transform duration-500 ease-in-out w-full"
            style="width: 100%">
            <!-- Slide 1 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none">
              <div class="w-10 flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
                <div class="bg-gradient2 w-[2px] flex-grow" style="height: 120px"></div>
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                 Intellivon’s AI-powered communication solutions transformed the way we collaborate across departments. The seamless integration of their system increased our team’s productivity, making communication smoother and more effective.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    Head of IT, Global Manufacturing Corporation
                  </div>
                </div>
              </div>
            </div>
            <!-- Slide 2 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none">
              <div class="w-10 flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
                <div class="bg-gradient2 w-[2px] flex-grow" style="height: 120px"></div>
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  With Intellivon’s enterprise communication system, our internal processes are now more streamlined than ever. Their custom-tailored solution improved cross-functional communication, reducing project delays.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    VP of Operations, Multinational Technology Firm
                  </div>
                </div>
              </div>
            </div>
            <!-- Slide 3 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none">
              <div class="w-10 flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
                <div class="bg-gradient2 w-[2px] flex-grow" style="height: 120px"></div>
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  Since we started using Intellivon’s AI communication platform, our customer service team has been able to respond much quicker. It's made a huge difference in how satisfied our clients are and has really improved retention. Their solution has truly transformed our service.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    Customer Service Manager, Financial Services Provider
                  </div>
                </div>
              </div>
            </div>
            <!-- Slide 4 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none">
              <div class="w-10 flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
                <div class="bg-gradient2 w-[2px] flex-grow" style="height: 120px"></div>
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  Intellivon’s communication solutions were exactly what we needed to grow our operations. Their AI-powered tools streamlined our repetitive processes, significantly boosting our efficiency and helping us make quicker, smarter decisions.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    Chief Technology Officer, Healthcare Enterprise
                  </div>
                </div>
              </div>
            </div>
            <!-- Slide 5 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none">
              <div class="w-10 flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
                <div class="bg-gradient2 w-[2px] flex-grow" style="height: 120px"></div>
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black" stroke-width="3" stroke-linecap="round" />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  The AI-powered communication system from Intellivon has truly transformed how our team works together. It’s simplified our communication flow, making collaboration smoother and helping us reduce internal miscommunications. As a result, we’re more agile and responsive than ever before
                  <div class="text-xl font-medium font-urbanist text-black1">
                    Senior Project Manager, Global Retail Brand
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div id="testimonial-dots" class="flex items-center justify-center gap-2 mt-5"></div>
        </div>
      </div>
    </div>
  </div>
  <!-- Testimonial Script -->
  <script>
    const testimonialSlider = document.getElementById("testimonial-slider");
    const testimonialTrack = document.getElementById("testimonial-track");
    const testimonialSlides = document.querySelectorAll(
      "#testimonial-track .slide"
    );
    const testimonialPrev = document.getElementById("testimonial-prev");
    const testimonialNext = document.getElementById("testimonial-next");
    const testimonialDots = document.getElementById("testimonial-dots");

    let testimonialIndex = 0;
    const testimonialVisibleDots = 3;
    const testimonialTotalSlides = testimonialSlides.length;

    function updateTestimonialDots() {
      const currentDotGroup = Math.floor(
        testimonialIndex / testimonialVisibleDots
      );
      testimonialDots.innerHTML = "";
      for (let i = 0; i < testimonialVisibleDots; i++) {
        const dotIndex = currentDotGroup * testimonialVisibleDots + i;
        if (dotIndex >= testimonialTotalSlides) break;
        const dot = document.createElement("div");
        dot.className =
          "h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300";
        dot.style.width = dotIndex === testimonialIndex ? "70px" : "28px";
        dot.style.opacity = dotIndex === testimonialIndex ? "1" : "0.5";
        testimonialDots.appendChild(dot);
      }
    }

    function updateTestimonialSlider() {
      testimonialTrack.style.transform = `translateX(-${testimonialIndex * 100
        }%)`;
      updateTestimonialDots();
    }

    testimonialNext.addEventListener("click", () => {
      testimonialIndex = (testimonialIndex + 1) % testimonialTotalSlides;
      updateTestimonialSlider();
    });

    testimonialPrev.addEventListener("click", () => {
      testimonialIndex =
        (testimonialIndex - 1 + testimonialTotalSlides) %
        testimonialTotalSlides;
      updateTestimonialSlider();
    });

    updateTestimonialSlider();
    // Auto-slide every 2 seconds
    setInterval(() => {
      testimonialIndex = (testimonialIndex + 1) % testimonialTotalSlides;
      updateTestimonialSlider();
    }, 2000);
  </script>
</section>

<!-- BLOGS -->
<!-- BLOGS Section with Swiper -->
<section class="py-24 w-full bg-cover px-5 lg:px-10 relative overflow-hidden">
  <div class="container">
    <div class="flex items-end justify-between mt-6 mb-3 w-full">
      <div class="w-full">
        <div class="w-full flex flex-col gap-5 items-start">
          <div class="text-md font-semibold text-[#656565]">BLOGS</div>
          <div class="flex flex-col lg:flex-row gap-5 lg:gap-0 w-full justify-between">
            <div class="w-full text-4xl flex-wrap gap-3 flex items-center font-bold text-black1 font-urbanist">
              The Latest from
              <div class="text-gradient">Intellivon</div>
            </div>
            <div class="lg:w-1/3">
              <a href="https://intellivon.com/blog/" target="_blank">
                <button type="button"
                  class="relative px-3 py-3 w-fit flex justify-center text-white font-medium rounded-full bg-white overflow-hidden group">
                  <span
                    class="relative z-10 text-blue text-nowrap text-sm lg:text-md items-center lg:items-normal flex gap-2">
                    Know More About Our Insights
                    <img
                      src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/know-more-capabilities-arrow.svg" />
                  </span>
                  <div
                    class="absolute inset-0 bg-gradient-to-l from-[#ab00ff] via-[#7000eb] to-[#00c8eb] rounded-full p-[1px]">
                    <div class="h-full w-full bg-white rounded-full"></div>
                  </div>
                </button>
              </a>
            </div>
          </div>
          <h3 class="text-grey1 text-base font-medium lg:w-1/2">
            Our exclusive platform where we share expert perspectives and guidance for your AI journey.
          </h3>
          <div class="flex gap-5 w-full items-center z-10">
            <?php echo do_shortcode( '[elementor-template id="1908"]'); ?>
          </div>
        </div>
      </div>
    </div>
    <!-- Background Decoration -->
    <div class="absolute right-0 top-0 w-[468px] h-[634px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="468" height="634" viewBox="0 0 468 634" fill="none">
        <g filter="url(#filter0_f_47_15221)">
          <path
            d="M564 197C564 126.86 507.14 70 437 70C366.86 70 310 126.86 310 197C310 267.14 366.86 324 437 324C507.14 324 564 267.14 564 197Z"
            fill="#7C3BAF" />
        </g>
        <defs>
          <filter id="filter0_f_47_15221" x="0.200012" y="-239.8" width="873.6" height="873.6"
            filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_47_15221" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="absolute left-0 top-[30%] w-[407px] h-[823px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="407" height="823" viewBox="0 0 407 823" fill="none">
        <g filter="url(#filter0_f_47_15222)">
          <path
            d="M97 437C97 366.86 40.1402 310 -30 310C-100.14 310 -157 366.86 -157 437C-157 507.14 -100.14 564 -30 564C40.1402 564 97 507.14 97 437Z"
            fill="#E61C42" fill-opacity="0.6" />
        </g>
        <defs>
          <filter id="filter0_f_47_15222" x="-466.8" y="0.200012" width="873.6" height="873.6"
            filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_47_15222" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="hidden lg:block absolute left-[30%] top-[30%] w-[821px] h-[744px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="821" height="744" viewBox="0 0 821 744" fill="none"
        class="w-max-20">
        <g filter="url(#filter0_f_47_15226)">
          <path
            d="M511 410.5C511 354.995 466.005 310 410.5 310C354.995 310 310 354.995 310 410.5C310 466.005 354.995 511 410.5 511C466.005 511 511 466.005 511 410.5Z"
            fill="#E61C42" />
        </g>
        <defs>
          <filter id="filter0_f_47_15226" x="0.200012" y="0.200012" width="820.6" height="820.6"
            filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="154.9" result="effect1_foregroundBlur_47_15226" />
          </filter>
        </defs>
      </svg>
    </div>
  </div>
</section>

<!-- CONTACT US FORM START -->
<section class="w-full relative bg-[#E4EAF2] py-20 px-5 lg:px-10">
  <div class="flex flex-col gap-8 container">
    <div class="text-md font-semibold text-[#656565]">CONTACT US</div>
    <div class="text-4xl leading-[1.25] font-semibold mt-10 lg:mt-0">
      Connect with Our
      <span class="text-gradient"> AI Experts </span>
      Today
    </div>
    <div class="w-full py-8">
      <?php echo do_shortcode( '[wpforms id="88"]'); ?>
    </div>
  </div>
</section>
<!-- CONTACT US FORM END -->

<!-- FAQ -->
<!-- Complete FAQ Section with Accordion and Smooth Transition -->
<section class="w-full px-5 lg:px-10 py-14 lg:py-20 bg-[#E4EAF2] relative overflow-hidden">
  <div class="container flex flex-col gap-5 items-center">
    <!-- Heading -->
    <div class="flex justify-between items-center w-full">
      <div class="text-md font-semibold text-[#656565]">FAQ</div>
    </div>
    <div class="flex flex-col w-5/6 mt-5">
      <!-- FAQ Item 1 -->
      <div class="faq-item">
        <div class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer">
          <div class="font-medium text-xl">
            Q1. What is an AI Enterprise Communication System?
          </div>
          <div class="faq-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27" fill="none">
              <!-- vertical line -->
              <path class="vertical-path" d="M13.2227 2.61133V23.7671" stroke="black" stroke-width="4.6301"
                stroke-linecap="round" stroke-linejoin="round" />
              <!-- horizontal line -->
              <path d="M23.8008 13.1895L2.645 13.1895" stroke="black" stroke-width="4.6301" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8">
          <p class="text-base text-[#333]">
            An AI Enterprise Communication System integrates AI into business communication to automate tasks, enhance efficiency, personalize interactions, and provide data-driven insights for both internal and external communications.
          </p>
        </div>
      </div>
      <!-- FAQ Item 2 -->
      <div class="faq-item">
        <div class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer">
          <div class="font-medium text-xl">
            Q2. How does AI improve internal communication within an enterprise?
          </div>
          <div class="faq-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path class="vertical-path" d="M13.2227 2.61133V23.7671" stroke="black" stroke-width="4.6301"
                stroke-linecap="round" stroke-linejoin="round" />
              <path d="M23.8008 13.1895L2.645 13.1895" stroke="black" stroke-width="4.6301" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8">
          <p class="text-base text-[#333]">
            AI automates administrative tasks, enhances knowledge sharing, and improves cross-department collaboration with real-time translation and content recommendations.
          </p>
        </div>
      </div>
      <!-- FAQ Item 3 -->
      <div class="faq-item">
        <div class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer">
          <div class="font-medium text-xl">
            Q3. What are the benefits of using AI for external communication?
          </div>
          <div class="faq-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path class="vertical-path" d="M13.2227 2.61133V23.7671" stroke="black" stroke-width="4.6301"
                stroke-linecap="round" stroke-linejoin="round" />
              <path d="M23.8008 13.1895L2.645 13.1895" stroke="black" stroke-width="4.6301" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8">
          <p class="text-base text-[#333]">
            AI improves customer support with 24/7 chatbots, personalizes marketing, and predicts customer needs, fostering stronger client relationships.
          </p>
        </div>
      </div>
      <!-- FAQ Item 4 -->
      <div class="faq-item">
        <div class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer">
          <div class="font-medium text-xl">
            Q4. What key features should I look for in an AI Enterprise Communication System?
          </div>
          <div class="faq-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path class="vertical-path" d="M13.2227 2.61133V23.7671" stroke="black" stroke-width="4.6301"
                stroke-linecap="round" stroke-linejoin="round" />
              <path d="M23.8008 13.1895L2.645 13.1895" stroke="black" stroke-width="4.6301" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8">
          <p class="text-base text-[#333]">
            Look for NLP, automation, real-time translation, data analytics, integration with existing tools, omnichannel support, and strong security/compliance.
          </p>
        </div>
      </div>
      <!-- FAQ Item 5 -->
      <div class="faq-item">
        <div class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer">
          <div class="font-medium text-xl">
            Q5. How does AI contribute to cost reduction in enterprise communication?
          </div>
          <div class="faq-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path class="vertical-path" d="M13.2227 2.61133V23.7671" stroke="black" stroke-width="4.6301"
                stroke-linecap="round" stroke-linejoin="round" />
              <path d="M23.8008 13.1895L2.645 13.1895" stroke="black" stroke-width="4.6301" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8">
          <p class="text-base text-[#333]">
            AI reduces costs by automating tasks, improving efficiency, minimizing errors, and providing 24/7 support, reducing the need for large human teams.
          </p>
        </div>
      </div>
      <!-- FAQ Item 6 -->
      <div class="faq-item">
        <div class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer">
          <div class="font-medium text-xl">
            Q6. Can an AI communication system support remote and hybrid teams effectively?
          </div>
          <div class="faq-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path class="vertical-path" d="M13.2227 2.61133V23.7671" stroke="black" stroke-width="4.6301"
                stroke-linecap="round" stroke-linejoin="round" />
              <path d="M23.8008 13.1895L2.645 13.1895" stroke="black" stroke-width="4.6301" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8">
          <p class="text-base text-[#333]">
            Yes, AI communication systems provide tools for real-time collaboration, secure access, and seamless communication, supporting remote and hybrid teams.
          </p>
        </div>
      </div>
      <!-- FAQ Item 7 -->
      <div class="faq-item">
        <div class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer">
          <div class="font-medium text-xl">
            Q7. Is data privacy and security maintained with AI communication systems?
          </div>
          <div class="faq-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path class="vertical-path" d="M13.2227 2.61133V23.7671" stroke="black" stroke-width="4.6301"
                stroke-linecap="round" stroke-linejoin="round" />
              <path d="M23.8008 13.1895L2.645 13.1895" stroke="black" stroke-width="4.6301" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8">
          <p class="text-base text-[#333]">
            Yes, reputable systems use encryption, follow global data protection regulations (like GDPR), and implement strong security protocols to safeguard data.
          </p>
        </div>
      </div>
      <!-- FAQ Item 8 -->
      <div class="faq-item">
        <div class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer">
          <div class="font-medium text-xl">
            Q8. Will AI replace human roles in enterprise communication?
          </div>
          <div class="faq-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27" fill="none">
              <path class="vertical-path" d="M13.2227 2.61133V23.7671" stroke="black" stroke-width="4.6301"
                stroke-linecap="round" stroke-linejoin="round" />
              <path d="M23.8008 13.1895L2.645 13.1895" stroke="black" stroke-width="4.6301" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8">
          <p class="text-base text-[#333]">
            AI will augment human roles, automating routine tasks, while empowering employees to focus on strategic, creative, and emotionally intelligent work.
          </p>
        </div>
      </div>
    </div>

    <!-- Background Decoration unchanged -->
    <div class="absolute top-0 right-0 w-[481px] h-[527px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="481" height="527" viewBox="0 0 481 527" fill="none">
        <g filter="url(#filter0_f_342_636)">
          <path
            d="M486 184.5C486 263.201 421.977 327 343 327C264.023 327 200 263.201 200 184.5C200 105.799 264.023 42 343 42C421.977 42 486 105.799 486 184.5Z"
            fill="#E61C42" fill-opacity="0.2" />
        </g>
        <defs>
          <filter id="filter0_f_342_636" x="0" y="-158" width="686" height="685" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="100" result="effect1_foregroundBlur_342_636" />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="absolute bottom-2 left-0 w-[453px] h-[595px] overflow-hidden pointer-events-none">
      <svg xmlns="http://www.w3.org/2000/svg" width="453" height="595" viewBox="0 0 453 595" fill="none">
        <g filter="url(#filter0_f_342_637)">
          <path
            d="M253 342.5C253 421.201 188.977 485 110 485C31.0233 485 -33 421.201 -33 342.5C-33 263.799 31.0233 200 110 200C188.977 200 253 263.799 253 342.5Z"
            fill="#7C3BAF" fill-opacity="0.3" />
        </g>
        <defs>
          <filter id="filter0_f_342_637" x="-233" y="0" width="686" height="685" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
            <feGaussianBlur stdDeviation="100" result="effect1_foregroundBlur_342_637" />
          </filter>
        </defs>
      </svg>
    </div>
  </div>
</section>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".faq-item").forEach((item) => {
      const questionDiv = item.querySelector(".cursor-pointer");
      const answerDiv = item.querySelector(".faq-answer");
      const svgIcon = item.querySelector("svg");
      const verticalPath = svgIcon.querySelector(".vertical-path");

      questionDiv.addEventListener("click", () => {
        const isCollapsed =
          !answerDiv.style.maxHeight || answerDiv.style.maxHeight === "0px";

        if (isCollapsed) {
          // Open: set maxHeight to content height, opacity to 1
          const scrollH = answerDiv.scrollHeight;
          answerDiv.style.maxHeight = scrollH + "px";
          answerDiv.style.opacity = "1";
          // Hide vertical line to become minus
          if (verticalPath) verticalPath.style.display = "none";
        } else {
          // Close: collapse
          answerDiv.style.maxHeight = "0";
          answerDiv.style.opacity = "0";
          // Show vertical line again (plus)
          if (verticalPath) verticalPath.style.display = "";
        }
      });
    });
  });
</script>
<?php get_footer(); ?>