<?php /* Template Name: Digital Product Engineering */ ?>
<?php get_header(); ?>
<!-- Intellivon Menubar Start -->
<!-- developed by - faiz -->
<!-- Intellivon Menubar End -->
<!-- HERO SECTION -->
<div class="w-full bg-[#040E32] pt-0">
  <div class="flex">
    <div class="lg:w-full flex flex-col gap-5 px-10 justify-center py-10 lg:p-[150px] lg:text-center">
      <h1 class="font-bold text-4xl lg:text-5xl text-white">
        Build Game-Changing Digital Products with 
        <span class="text-gradient">Engineering That Scales</span>
      </h1>
      <p class="text-white text-lg font-medium">
        At Intellivon, we co-engineer scalable digital products that deliver real business value. From legacy modernization to full-stack innovation, our teams bring deep technical expertise and agile execution to every project.
      </p>
      <div class="flex lg:justify-center">
      <a
        href="https://intellivon.com/ai-strategy-call-booking-confirmation/"
        target="_blank"
      >
        <button
          class="w-fit flex gap-2 bg-gradient-to-r from-[#9A37B2] to-[#E61C42] text-white font-medium px-6 py-3 rounded-full shadow-lg hover:scale-105 transition border border-[#7C3BAF]"
        >
          Talk to Our Digital Engineering Experts
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="25"
            viewBox="0 0 24 25"
            fill="none"
          >
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
              fill="white"
            />
          </svg>
        </button>
      </a>
      </div>
    </div>

    <!--<div class="hidden lg:block right-0 top-0 w-1/2">-->
    <!--  <img-->
    <!--    src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/ai_development_services-hero.webp"-->
    <!--    class="w-full h-full"-->
    <!--  />-->
    <!--</div>-->
  </div>
</div>
<!--
<div class="w-full bg-[#040E32] pt-0">
  <div class="flex">
    <div
      class="lg:w-1/2 flex flex-col gap-5 px-10 justify-center py-10 lg:py-0"
    >
      <h1 class="font-bold text-4xl lg:text-5xl text-white">
        Build Game-Changing Digital Products with 
        <span class="text-gradient">Engineering That Scales</span>
      </h1>
      <p class="text-white text-lg font-medium">
        At Intellivon, we co-engineer scalable digital products that deliver real business value. From legacy modernization to full-stack innovation, our teams bring deep technical expertise and agile execution to every project.
      </p>
      <a
        href="https://intellivon.com/ai-strategy-call-booking-confirmation/"
        target="_blank"
      >
        <button
          class="w-fit flex gap-2 bg-gradient-to-r from-[#9A37B2] to-[#E61C42] text-white font-medium px-6 py-3 rounded-full shadow-lg hover:scale-105 transition border border-[#7C3BAF]"
        >
          Talk to Our Digital Engineering Experts
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="25"
            viewBox="0 0 24 25"
            fill="none"
          >
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
              fill="white"
            />
          </svg>
        </button>
      </a>
    </div>

    <div class="hidden lg:block right-0 top-0 w-1/2">
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/ai_development_services-hero.webp"
        class="w-full h-full"
      />
    </div>
  </div>
</div>
-->

<!-- OUR CLIENTS -->
<section
  class="w-full pt-10 lg:pt-0"
  style="
    background: linear-gradient(
      95deg,
      rgba(124, 59, 175, 0.3) 0.11%,
      rgba(230, 28, 66, 0.3) 80.8%
    );
  "
>
  <div class="flex flex-wrap items-center">
    <!-- Left column: Heading -->
    <div class="w-full lg:w-2/3 lg:pl-10 px-10 lg:px-0">
      <div class="flex flex-col gap-5 items-start">
        <div class="text-md font-semibold text-[#656565]">OUR CLIENTS</div>
        <h2
          class="text-4xl items-center font-bold text-black1 font-urbanist leading-snug tracking-[0.5px] gap-1"
        >
          Empowering Global Brands with 
          <span class="text-gradient">Next-Generation Digital Solutions</span>
        </h2>
        <p
          class="mb-4 md:mb-0 text-base font-medium text-grey1 mt-2 w-full tracking-[0.25px] pr-5 mb-12"
        >
          We collaborate with global enterprises to develop user-driven, innovation-focused digital products that exceed expectations and deliver real business outcomes.
        </p>
      </div>
    </div>
    <!-- Right column: Image -->
    <div class="w-full lg:w-1/3 p-10">
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/intellivon-client-image.webp"
        alt="Our Clients"
        width="620"
        height="550"
        class="w-full lg:h-full lg:mb-12 xl:mb-0 object-cover object-center rounded-md transition-all duration-300"
      />
    </div>
  </div>
</section>

<!-- SERVICES - MARQUEE -->
<section>
  <!-- Marquee logos -->
  <div
    class="w-full overflow-hidden whitespace-nowrap relative bg-[#10182C] py-5"
  >
    <div
      class="marquee flex items-center gap-x-16 w-max max-w-none animate-marquee"
    >
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/gold-gym.webp"
        alt="Gold Gym"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/sonangol.webp"
        alt="Sonangol"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/buzztime.webp"
        alt="Buzztime"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/hyundai.png"
        alt="Hyundai"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/rusam.webp"
        alt="Rusam"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <!-- repeat logos for continuous scroll -->
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/gold-gym.webp"
        alt="Gold Gym"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/sonangol.webp"
        alt="Sonangol"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/buzztime.webp"
        alt="Buzztime"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/hyundai.png"
        alt="Hyundai"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/rusam.webp"
        alt="Rusam"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <!-- repeat logos for continuous scroll -->
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/gold-gym.webp"
        alt="Gold Gym"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/sonangol.webp"
        alt="Sonangol"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/buzztime.webp"
        alt="Buzztime"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/hyundai.png"
        alt="Hyundai"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/rusam.webp"
        alt="Rusam"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <!-- repeat logos for continuous scroll -->
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/gold-gym.webp"
        alt="Gold Gym"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/sonangol.webp"
        alt="Sonangol"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/buzztime.webp"
        alt="Buzztime"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/hyundai.png"
        alt="Hyundai"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
      <img
        src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/rusam.webp"
        alt="Rusam"
        width="80"
        height="80"
        class="w-20 grayscale hover:grayscale-0"
      />
    </div>
  </div>
  <style>
    /* Marquee animation */
    @keyframes marquee {
      0% {
        transform: translateX(0);
      }

      100% {
        transform: translateX(-50%);
      }
    }

    .animate-marquee {
      animation: marquee 20s linear infinite;
    }
  </style>
</section>

<!-- OUR SERVICES -->
<section>
  <div class="bg-services-gradient relative px-5 lg:px-10 overflow-hidden">
    <div class="container flex flex-col items-center lg:pt-14 pb-4 py-5 gap-10">
      <!-- content -->
      <div class="w-full pr-5">
        <div class="w-full flex flex-col gap-5 items-start">
          <div class="text-md font-semibold text-[#656565]">OUR SERVICES</div>
          <h2
            class="text-4xl font-bold text-black1 font-urbanist leading-snug tracking-[0.5px] w-full"
          > 
          Our
            <span class="text-gradient"
              > Digital Product Engineering Services</span
            >
          </h2>
          <p
            class="mb-4 md:mb-0 text-base font-medium text-grey1 mt-2 w-full tracking-[0.25px] pr-5 mb-12"
          >
            We partner with your product team to engineer innovative, user-centric digital products that drive measurable business impact.
          </p>
        </div>
      </div>

      <div
        class="bg-white rounded-3xl flex flex-col lg:flex-row gap-10 p-8 w-5/6 z-10"
        id="servicesContainer"
      >
        <div
          class="flex flex-col gap-5 lg:w-1/3 h-[70vh] overflow-y-scroll pt-5 px-5"
          id="serviceButtons"
        >
          <!-- Button 1 -->
          <div class="rounded-xl">
            <div
              class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
            >
              Product Strategy
            </div>
          </div>
          <!-- Button 2 -->
          <div class="rounded-xl">
            <div
              class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
            >
              Product and Platform Engineering
            </div>
          </div>
          <!-- Button 3 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
          >
            Architecture Advisory
          </div>
          <!-- Button 4 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
          >
            Modernization
          </div>
          <!-- Button 5 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
          >
            QA Engineering
          </div>
          <!-- Button 6 -->
          <div
            class="rounded-xl flex items-center justify-center font-bold text-lg p-5 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
          >
            Managed Sustainance
          </div>
        </div>

        <div
          class="lg:w-2/3 flex flex-col gap-5 lg:gap-10 pt-5"
          id="serviceContent"
        >
          <!-- <div class="font-bold text-lg lg:text-2xl">
                            AI Strategy & Roadmapping
                        </div> -->

          <div class="grid gap-3 grid-cols-1 lg:grid-cols-2">
            <!-- button 1 -->
            <div
              class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]"
            >
              <div
                class="text-md bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
              >
                Product Strategy
              </div>
            </div>

            <!-- button 2 -->
            <div
              class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]"
            >
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
              >
                Product and Platform Engineering
              </div>
            </div>

            <!-- button 3 -->
            <div
              class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]"
            >
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
              >
                Architecture Advisory
              </div>
            </div>

            <!-- button 4 -->
            <div
              class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]"
            >
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
              >
                Modernization
              </div>
            </div>

            <!-- button 5 -->
            <div
              class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]"
            >
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
              >
                QA Engineering
              </div>
            </div>
            <!-- button 6 -->
            <div
              class="rounded-xl pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]"
            >
              <div
                class="bg-white flex justify-center items-center rounded-xl font-medium py-3 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]"
              >
                Managed Sustainance
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Background Decoration -->
    <div
      class="absolute top-0 right-0 w-[512px] h-[512px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="512"
        height="512"
        viewBox="0 0 512 512"
        fill="none"
      >
        <g filter="url(#filter0_f_2_313)">
          <circle cx="422" cy="102" r="112" fill="#D200D2" />
        </g>
        <defs>
          <filter
            id="filter0_f_2_313"
            x="0.200012"
            y="-319.8"
            width="843.6"
            height="843.6"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="154.9"
              result="effect1_foregroundBlur_2_313"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div
      class="absolute bottom-0 left-0 w-[534px] h-[379px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="534"
        height="379"
        viewBox="0 0 534 379"
        fill="none"
      >
        <g filter="url(#filter0_f_288_195)">
          <circle cx="112" cy="422" r="112" fill="#D200D2" fill-opacity="0.4" />
        </g>
        <defs>
          <filter
            id="filter0_f_288_195"
            x="-309.8"
            y="0.200012"
            width="843.6"
            height="843.6"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="154.9"
              result="effect1_foregroundBlur_288_195"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div
      class="absolute bottom-0 left-[30%] w-[844px] h-[573px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="844"
        height="573"
        viewBox="0 0 844 573"
        fill="none"
      >
        <g filter="url(#filter0_f_288_194)">
          <circle cx="422" cy="422" r="112" fill="#D200D2" />
        </g>
        <defs>
          <filter
            id="filter0_f_288_194"
            x="0.200012"
            y="0.200012"
            width="843.6"
            height="843.6"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="154.9"
              result="effect1_foregroundBlur_288_194"
            />
          </filter>
        </defs>
      </svg>
    </div>
  </div>

  <script>
    const services = [
      {
        title: "Product Strategy",
        description:
          "We craft tailored product strategies with clear roadmaps and implementation plans that strike a balance between innovation and scalability. Our approach helps businesses align their product vision with long-term goals, ensuring sustainable growth and market leadership.",
        points: [
"Focus workshops",
"Engineering projections ",
"Distribution and adoption planning ",
"Market Research and Competitive Analysis",
"User-Centered Design and Experience Mapping",
"Product Roadmap & Iterative Development",

        ],
      },
      {
        title: "Product and Platform Engineering",
        description:
          "We help businesses modernize legacy systems by leveraging cloud-native development, microservices, and robust software engineering practices. Our solutions ensure your products are adaptable, scalable, and ready to meet future demands.",
        points: [
"Digital product development",
"Digital platform development ",
"Co-engineering",
"Cloud Migration & Optimization",
"Microservices Architecture & Implementation",
"Continuous Integration & Delivery (CI/CD)",

        ],
      },
      {
        title: "Architecture Advisory",
        description:
          "Our architecture advisory services focus on optimizing data architecture and technology foundations to support your business growth. We ensure that your technology infrastructure is resilient, scalable, and capable of handling complex business needs.",
        points: [
"Architecture auditing and consulting",
"Enterprise platform strategy",
"Data architecture consultation",
"Cloud Strategy & Adoption",
"Technology Stack Optimization",
"High-Availability & Disaster Recovery Planning",

        ],
      },
      {
        title: "Modernization",
        description:
          "We utilize cutting-edge technologies, such as generative AI, to enhance legacy software, enhancing the user experience and reducing operational costs. Our modernization approach ensures your systems stay competitive and deliver greater business value.",
        points: [
"Platform modernization",
"Experience modernization",
"Intelligent features implementation",
"Legacy System Integration",
"Cloud-Native Transformation",
"User Interface (UI) Overhaul",

        ],
      },

      {
        title: "QA Engineering",
        description:
          "Our QA engineering services integrate test automation and continuous integration to maintain the highest quality standards. We streamline your product development process, ensuring fast, reliable releases with minimal errors.",
        points: [
"Test automation",
"Non-functional testing",
"Shift-left testing",
"Performance Testing",
"Security Testing",
"Regression Testing",

        ],
      },

      {
        title: "Managed Sustainance",
        description:
          "We provide proactive enhancements and ongoing support to keep your products competitive in the market. Our managed sustenance services ensure that your product evolves with changing business needs, keeping it aligned with user expectations and industry standards.",
        points: [
"Continuous product sustenance",
"Business process sustenance",
"IT sustenance",
"Product Upgrade and Feature Enhancement",
"User Experience (UX) Optimization",
"Proactive IT Support & Maintenance",

        ],
      },
    ];

    const buttonsContainer = document.getElementById("serviceButtons");
    const contentContainer = document.getElementById("serviceContent");

    function renderButtons(activeIndex = 0) {
      buttonsContainer.innerHTML = "";
      services.forEach((service, index) => {
        const isActive = index === activeIndex;
        const btnWrapper = document.createElement("div");
        btnWrapper.className = `rounded-xl ${
          isActive ? "pl-1 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]" : ""
        }`;

        btnWrapper.innerHTML = `
                <div class="bg-white flex justify-between items-center rounded-xl font-bold text-sm lg:text-base px-3 py-4 w-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)] cursor-pointer" onclick="renderContent(${index})">
                <div class="w-full">${service.title}</div>
                ${
                  isActive
                    ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z" fill="url(#paint0_linear_2_494)"/>
                    <defs>
                    <linearGradient id="paint0_linear_2_494" x1="6.5" y1="7" x2="22" y2="13" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#7C3BAF"/>
                        <stop offset="1" stop-color="#E61C42"/>
                    </linearGradient>
                    </defs>
                </svg>`
                    : ""
                }
                </div>
            `;
        buttonsContainer.appendChild(btnWrapper);
      });
    }

    function renderContent(index) {
      renderButtons(index);
      const service = services[index];

      contentContainer.innerHTML = `
            <div class="font-bold text-lg lg:text-2xl">${service.title}</div>
            
                <div class="text-[#333333] text-sm lg:text-base">${
                  service.description
                }</div>
                <div class="grid gap-3 grid-cols-1 lg:grid-cols-2">
                ${service.points
                  .map(
                    (point) => `
                    <div class="pl-0.5 bg-gradient-to-b from-[#7C3BAF] to-[#E61C42]">
                    <div class="bg-gradient-to-r from-[#ceb0dc] via-[#dfaac9] to-[#eba7bf] flex justify-start items-center text-sm lg:text-md font-bold py-4 px-3 w-full h-full shadow-[0px_4px_24px_-1px_rgba(124,59,175,0.6)]">${point}</div>
                    </div>
                `
                  )
                  .join("")}
                </div>
            
            `;
    }
    // Initial Render
    renderButtons(0);
    renderContent(0);
  </script>
</section>

<!-- OUR PROCESS -->
<section class="bg-landingGen py-16 lg:py-24 bg-cover px-5 lg:px-10">
  <div class="container">
    <div class="flex items-end justify-between mt-6 mb-3">
      <!-- Heading -->
      <div class="flex flex-col gap-3 w-full">
        <div class="text-md font-semibold text-[#656565]">OUR PROCESS</div>
        <h2
          class="text-4xl md:gap-3 items-center font-bold text-black1 font-urbanist leading-snug tracking-[0.5px]"
        >
          From Concept to Launch Our Digital Product Engineering Process
          <span class="text-gradient"> in 3 Steps </span>
        </h2>
        <p class="text-[#333333] w-full lg:w-3/4 text-base font-medium">
          We follow a structured, collaborative approach to digital product engineering, from concept to post-deployment. Our process prioritizes every stage of the product lifecycle, ensuring scalable, innovative solutions that align with your business goals.
        </p>
      </div>
    </div>
    <!-- Consulting Cards -->
    <div
      id="consulting-cards"
      class="flex flex-col lg:flex-row justify-center bg-white mt-8"
    >
      <!-- Step 1 -->
      <div
        class="card w-full lg:w-1/3 p-6 border-2 border-transparent bg-zinc-50 rounded-md"
        style="
          border-radius: 12px;
          background: linear-gradient(142deg, #fff 0%, #e0faff 99.14%);
        "
      >
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-black2 font-light text-sm">Step 1</h3>
            <h3 class="text-black2 font-bold font-urbanist text-xl">
              Evaluate
            </h3>
          </div>
          <!-- ArrowRight SVG -->
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="40"
            height="40"
            viewBox="0 0 40 40"
            fill="none"
          >
            <path
              d="M29.4825 18.7501H6.25C5.91848 18.7501 5.60054 18.8818 5.36612 19.1162C5.1317 19.3507 5 19.6686 5 20.0001C5 20.3316 5.1317 20.6496 5.36612 20.884C5.60054 21.1184 5.91848 21.2501 6.25 21.2501H29.4825L20.365 30.3651C20.1303 30.5998 19.9984 30.9182 19.9984 31.2501C19.9984 31.5821 20.1303 31.9004 20.365 32.1351C20.5997 32.3698 20.9181 32.5017 21.25 32.5017C21.5819 32.5017 21.9003 32.3698 22.135 32.1351L33.385 20.8851C33.5014 20.769 33.5938 20.6311 33.6568 20.4792C33.7198 20.3273 33.7522 20.1645 33.7522 20.0001C33.7522 19.8357 33.7198 19.6729 33.6568 19.521C33.5938 19.3692 33.5014 19.2312 33.385 19.1151L22.135 7.86511C21.9003 7.6304 21.5819 7.49854 21.25 7.49854C20.9181 7.49854 20.5997 7.6304 20.365 7.86511C20.1303 8.09983 19.9984 8.41817 19.9984 8.75011C19.9984 9.08205 20.1303 9.4004 20.365 9.63511L29.4825 18.7501Z"
              fill="url(#paint0_linear_2_437)"
            />
            <defs>
              <linearGradient
                id="paint0_linear_2_437"
                x1="33.7522"
                y1="20.0001"
                x2="5"
                y2="20.0001"
                gradientUnits="userSpaceOnUse"
              >
                <stop stop-color="#FF00E1" />
                <stop offset="1" stop-color="#000DFF" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div class="grid grid-cols-2 gap-1 mt-4">
          <div class="p-3 bg-[#F7F7F7] h-44">
            <!-- AccordianArrow SVG -->
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Align digital solutions with your business goals and growth strategy.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Conduct in-depth market and user research to uncover key opportunities.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Collaborate to define actionable product requirements.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Assess current technology to ensure scalable and efficient development.
            </p>
          </div>
        </div>
      </div>
      <!-- Step 2 -->
      <div
        class="card w-full lg:w-1/3 p-6 border-2 border-transparent rounded-md"
        style="background: linear-gradient(142deg, #fff 0%, #d4d6ff 99.14%)"
      >
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-black2 font-light text-sm">Step 2</h3>
            <h3 class="text-black2 font-bold font-urbanist text-xl">Explore</h3>
          </div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="40"
            height="40"
            viewBox="0 0 40 40"
            fill="none"
          >
            <path
              d="M29.4825 18.7501H6.25C5.91848 18.7501 5.60054 18.8818 5.36612 19.1162C5.1317 19.3507 5 19.6686 5 20.0001C5 20.3316 5.1317 20.6496 5.36612 20.884C5.60054 21.1184 5.91848 21.2501 6.25 21.2501H29.4825L20.365 30.3651C20.1303 30.5998 19.9984 30.9182 19.9984 31.2501C19.9984 31.5821 20.1303 31.9004 20.365 32.1351C20.5997 32.3698 20.9181 32.5017 21.25 32.5017C21.5819 32.5017 21.9003 32.3698 22.135 32.1351L33.385 20.8851C33.5014 20.769 33.5938 20.6311 33.6568 20.4792C33.7198 20.3273 33.7522 20.1645 33.7522 20.0001C33.7522 19.8357 33.7198 19.6729 33.6568 19.521C33.5938 19.3692 33.5014 19.2312 33.385 19.1151L22.135 7.86511C21.9003 7.6304 21.5819 7.49854 21.25 7.49854C20.9181 7.49854 20.5997 7.6304 20.365 7.86511C20.1303 8.09983 19.9984 8.41817 19.9984 8.75011C19.9984 9.08205 20.1303 9.4004 20.365 9.63511L29.4825 18.7501Z"
              fill="url(#paint0_linear_2_461)"
            />
            <defs>
              <linearGradient
                id="paint0_linear_2_461"
                x1="33.7522"
                y1="20.0001"
                x2="5"
                y2="20.0001"
                gradientUnits="userSpaceOnUse"
              >
                <stop stop-color="#FF00E1" />
                <stop offset="1" stop-color="#000DFF" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div class="grid grid-cols-2 gap-1 mt-4">
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Brainstorm and prioritize features that drive innovation and meet user needs.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Design interactive prototypes and wireframes to visualize product’s flow.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Conduct technical assessments to ensure the feasibility of solutions.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Refine and validate concepts using real-user testing and iterative feedback.
            </p>
          </div>
        </div>
      </div>
      <!-- Step 3 -->
      <div
        class="card w-full lg:w-1/3 p-6 border-2 border-transparent rounded-md"
        style="background: linear-gradient(142deg, #fff 0%, #ffddfb 99.14%)"
      >
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-black2 font-light text-sm">Step 3</h3>
            <h3 class="text-black2 font-bold font-urbanist text-xl">Execute</h3>
          </div>
          <!-- Refresh SVG -->
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="40"
            height="40"
            viewBox="0 0 40 40"
            fill="none"
          >
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M14.1166 4.11654C14.351 3.88246 14.6687 3.75098 14.9999 3.75098C15.3312 3.75098 15.6489 3.88246 15.8833 4.11654L19.2166 7.44988C19.3912 7.62469 19.5101 7.84732 19.5582 8.08965C19.6063 8.33198 19.5816 8.58314 19.4871 8.81142C19.3925 9.03969 19.2325 9.23483 19.0271 9.3722C18.8218 9.50956 18.5803 9.58299 18.3333 9.58321H14.9999C12.2372 9.58321 9.58773 10.6807 7.63422 12.6342C5.68072 14.5877 4.58325 17.2372 4.58325 19.9999C4.58325 22.7625 5.68072 25.4121 7.63422 27.3656C9.58773 29.3191 12.2372 30.4165 14.9999 30.4165H15.8333C16.1648 30.4165 16.4827 30.5482 16.7171 30.7827C16.9516 31.0171 17.0833 31.335 17.0833 31.6665C17.0833 31.9981 16.9516 32.316 16.7171 32.5504C16.4827 32.7848 16.1648 32.9165 15.8333 32.9165H14.9999C11.5742 32.9165 8.2888 31.5557 5.86646 29.1333C3.44411 26.711 2.08325 23.4256 2.08325 19.9999C2.08325 16.5742 3.44411 13.2888 5.86646 10.8664C8.2888 8.44407 11.5742 7.08321 14.9999 7.08321H15.3166L14.1166 5.88321C13.8825 5.64883 13.751 5.33113 13.751 4.99988C13.751 4.66863 13.8825 4.35092 14.1166 4.11654ZM22.9166 8.33321C22.9166 8.00169 23.0483 7.68375 23.2827 7.44933C23.5171 7.21491 23.8351 7.08321 24.1666 7.08321H24.9999C28.4256 7.08321 31.711 8.44407 34.1334 10.8664C36.5557 13.2888 37.9166 16.5742 37.9166 19.9999C37.9166 23.4256 36.5557 26.711 34.1334 29.1333C31.711 31.5557 28.4256 32.9165 24.9999 32.9165H24.6833L25.8833 34.1165C26.0061 34.231 26.1046 34.369 26.1729 34.5223C26.2412 34.6756 26.2779 34.8412 26.2809 35.009C26.2839 35.1768 26.253 35.3436 26.1901 35.4992C26.1273 35.6549 26.0337 35.7962 25.915 35.9149C25.7963 36.0336 25.6549 36.1272 25.4992 36.1901C25.3436 36.2529 25.1769 36.2838 25.0091 36.2809C24.8412 36.2779 24.6757 36.2412 24.5224 36.1728C24.369 36.1045 24.231 36.006 24.1166 35.8832L20.7833 32.5499C20.6087 32.3751 20.4898 32.1524 20.4416 31.9101C20.3935 31.6678 20.4183 31.4166 20.5128 31.1883C20.6073 30.9601 20.7673 30.7649 20.9727 30.6276C21.1781 30.4902 21.4195 30.4168 21.6666 30.4165H24.9999C27.7626 30.4165 30.4121 29.3191 32.3656 27.3656C34.3191 25.4121 35.4166 22.7625 35.4166 19.9999C35.4166 17.2372 34.3191 14.5877 32.3656 12.6342C30.4121 10.6807 27.7626 9.58321 24.9999 9.58321H24.1666C23.8351 9.58321 23.5171 9.45151 23.2827 9.21709C23.0483 8.98267 22.9166 8.66473 22.9166 8.33321Z"
              fill="url(#paint0_linear_2_485)"
            />
            <defs>
              <linearGradient
                id="paint0_linear_2_485"
                x1="37.9166"
                y1="20.016"
                x2="2.08325"
                y2="20.016"
                gradientUnits="userSpaceOnUse"
              >
                <stop stop-color="#FF00E1" />
                <stop offset="1" stop-color="#000DFF" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div class="grid grid-cols-2 gap-1 mt-4">
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Apply agile development to deliver high-quality product increments quickly.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Work closely with your team to ensure alignment and address project hurdles.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Implement thorough testing and automation.
            </p>
          </div>
          <div class="p-3 bg-[#F7F7F7] h-44">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M12.7392 1H1V19H17.4348V13"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M5.69568 9.57101L9.60873 13.8567L19.0001 2.71387"
                stroke="#72C89A"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
            <p class="text-[12px] md:text-[15px] font-normal text-grey3 mt-2">
              Provide post-launch monitoring and updates.
            </p>
          </div>
        </div>
      </div>
    </div>
    <!-- Talk To Us button (mobile) -->
    <div class="md:hidden w-full flex items-center justify-center mt-4">
      <button
        type="button"
        class="relative px-4 py-2 text-white font-medium rounded-lg bg-white overflow-hidden group"
      >
        <span class="relative z-10 text-blue text-nowrap"> Talk To Us </span>
        <div
          class="absolute inset-0 bg-gradient-to-l from-[#ab00ff] via-[#7000eb] to-[#00c8eb] rounded-lg p-[1px]"
        >
          <div class="h-full w-full bg-white rounded-lg"></div>
        </div>
      </button>
    </div>
  </div>
  <script>
    // Cycle active consulting card every 3 seconds
    (() => {
      const cards = document.querySelectorAll("#consulting-cards > div.card");
      let activeIndex = 0;

      function updateCards() {
        cards.forEach((card, i) => {
          card.classList.remove("gradient-border", "rounded-md");
          card.classList.remove("bg-zinc-50");
          if (i === activeIndex) {
            card.classList.add("gradient-border", "rounded-md");
          }
          if (activeIndex === 0 && i === cards.length - 1) {
            cards[i].classList.add("bg-zinc-50");
          } else if (activeIndex === 1 && i === 0) {
            cards[i].classList.add("bg-zinc-50");
          } else if (activeIndex === 2 && i === 1) {
            cards[i].classList.add("bg-zinc-50");
          }
        });
      }

      updateCards();

      setInterval(() => {
        activeIndex = (activeIndex + 1) % cards.length;
        updateCards();
      }, 3000);
    })();
  </script>
</section>

<!-- LATEST CASE STUDY SECTION -->
<section class="w-full px-5 lg:px-10 bg-cover relative">
  <div class="container">
    <div class="flex flex-col items-end justify-between mt-6 mb-3 w-full">
      <div class="w-full flex flex-col gap-5 items-start">
        <!-- Section Heading -->
        <div class="text-md font-semibold text-[#656565]">CASE STUDY</div>
        <div
          class="flex flex-col gap-5 lg:gap-0 lg:flex-row justify-between w-full"
        >
          <h2
            class="w-full lg:w-11/12 text-4xl gap-3 font-bold text-black1 font-urbanist leading-snug tracking-[0.5px]"
          >
            Real-World Impact from Our 
            <span class="text-gradient">Digital Product Engineering Solutions</span>
          </h2>
          
          <div class="flex gap-2 mt-8 md:mt-0">
            <!-- Prev -->
            <svg
              id="custom-cs-prev"
              xmlns="http://www.w3.org/2000/svg"
              width="50"
              height="50"
              viewBox="0 0 50 50"
              fill="none"
              class="cursor-pointer"
            >
              <mask
                id="mask-prev"
                maskUnits="userSpaceOnUse"
                x="1"
                y="1"
                width="48"
                height="48"
              >
                <path
                  d="M25 4.17C13.49 4.17 4.17 13.49 4.17 25C4.17 36.51 13.49 45.83 25 45.83C36.51 45.83 45.83 36.51 45.83 25C45.83 13.49 36.51 4.17 25 4.17Z"
                  fill="white"
                  stroke="white"
                  stroke-width="5.33"
                  stroke-linejoin="round"
                />
                <path
                  d="M28.13 15.63L18.75 25L28.13 34.38"
                  stroke="black"
                  stroke-width="5.33"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </mask>
              <g mask="url(#mask-prev)">
                <path d="M50 50H0V0H50V50Z" fill="url(#paint-prev)" />
              </g>
              <defs>
                <linearGradient
                  id="paint-prev"
                  x1="50"
                  y1="25"
                  x2="-7.5"
                  y2="25"
                  gradientUnits="userSpaceOnUse"
                >
                  <stop stop-color="#7C3BAF" />
                  <stop offset="1" stop-color="#E61C42" />
                </linearGradient>
              </defs>
            </svg>
            <!-- Next -->
            <svg
              id="custom-cs-next"
              xmlns="http://www.w3.org/2000/svg"
              width="50"
              height="50"
              viewBox="0 0 50 50"
              fill="none"
              class="cursor-pointer"
            >
              <mask
                id="mask-next"
                maskUnits="userSpaceOnUse"
                x="1"
                y="1"
                width="48"
                height="48"
              >
                <path
                  d="M25 45.83C36.51 45.83 45.83 36.51 45.83 25C45.83 13.49 36.51 4.17 25 4.17C13.49 4.17 4.17 13.49 4.17 25C4.17 36.51 13.49 45.83 25 45.83Z"
                  fill="white"
                  stroke="white"
                  stroke-width="5.33"
                  stroke-linejoin="round"
                />
                <path
                  d="M21.88 34.38L31.25 25L21.88 15.63"
                  stroke="black"
                  stroke-width="5.33"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </mask>
              <g mask="url(#mask-next)">
                <path d="M0 0H50V50H0V0Z" fill="url(#paint-next)" />
              </g>
              <defs>
                <linearGradient
                  id="paint-next"
                  x1="5"
                  y1="31"
                  x2="62"
                  y2="32"
                  gradientUnits="userSpaceOnUse"
                >
                  <stop stop-color="#7C3BAF" />
                  <stop offset="1" stop-color="#E61C42" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
        <p
          class="capitalize mb-4 md:mb-0 text-base font-medium text-grey1 mt-2 md:w-8/12 tracking-[0.25px] pr-5"
        >
          Our data engineering solutions have enabled businesses across various industries to build digital products that consistently exceed user expectations and achieve significant ROI.
        </p>
        <!-- Slider with custom arrows -->
        <div class="flex justify-evenly items-center gap-2 md:gap-5 w-full">
          <!-- Swiper Wrapper -->
          <div class="swiper swiper-case-study w-full">
            <div class="swiper-wrapper bg-[#F2F7FF]">
              <!-- Slide 1 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide"
              >
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div
                    class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]"
                  >
                    <h3 class="text-xl md:text-3xl font-semibold">
                      Fintech Product Innovation with Data Engineering
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        A leading fintech company struggled with outdated legacy systems that couldn’t scale or handle real-time financial data processing. We overhauled its data architecture using AWS, Snowflake, and Kafka to enable seamless, real-time financial data processing, allowing it to adapt quickly to market trends and integrate third-party financial tools.
                      </p>
                      <p
                        class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm"
                      >
                        A leading fintech company struggled with outdated legacy systems that couldn’t scale or handle real-time financial data processing. We overhauled its data architecture using AWS, Snowflake, and Kafka to enable seamless, real-time financial data processing, allowing it to adapt quickly to market trends and integrate third-party financial tools.
                      </p>
                      <button
                        class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden"
                      >
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                        <span
                          >improvement in predictive maintenance accuracy.</span
                        >
                      <span class="xl:text-xl font-semibold">50%</span>
                    </li>
                    <li class="">
                        <span>Improving decision-making by</span>
                        <span class="xl:text-xl font-semibold">40%</span>
                    </li>
                    <li class="">
                        <span
                        >Boosted service flexibility by</span
                        >
                        <span class="xl:text-xl font-semibold">30%</span>
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a
                    href="https://intellivon.com/ai-strategy-call-booking-confirmation/"
                    target="_blank"
                  >
                    <div
                      class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button"
                    >
                      Explore more
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="25"
                        viewBox="0 0 24 25"
                        fill="none"
                      >
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                  </a>
                </div>
                <div
                  class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl"
                >
                  <img
                    src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-1.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl"
                  />
                </div>
              </div>
              <!-- Slide 2 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide"
              >
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div
                    class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]"
                  >
                    <h3 class="text-xl md:text-3xl font-semibold">
                      Energy Sector Efficiency with Smart Digital Products
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        An energy management company struggled with inefficient data collection, leading to delayed insights into energy usage. Intellivon developed a real-time data collection and analytics platform utilizing Apache Flink and AWS, enabling the instant analysis of sensor data to optimize energy usage and minimize waste.
                      </p>
                      <p
                        class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm"
                      >
                        An energy management company struggled with inefficient data collection, leading to delayed insights into energy usage. Intellivon developed a real-time data collection and analytics platform utilizing Apache Flink and AWS, enabling the instant analysis of sensor data to optimize energy usage and minimize waste.
                      </p>
                      <button
                        class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden"
                      >
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      <span>Improved energy usage predictions by</span>
                      <span class="xl:text-xl font-semibold">30%</span>
                    </li>
                    <li class="">
                      Reduced energy waste by <span class="xl:text-xl font-semibold">25%</span> with real-time data analysis                      
                    </li>
                    <li class="">
                      <span>Enhanced operational efficiency by</span>
                      <span class="xl:text-xl font-semibold">40%</span>
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a
                    href="https://intellivon.com/ai-strategy-call-booking-confirmation/"
                    target="_blank"
                  >
                    <div
                      class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button"
                    >
                      Explore more
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="25"
                        viewBox="0 0 24 25"
                        fill="none"
                      >
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                  </a>
                </div>
                <div
                  class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl"
                >
                  <img
                    src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-2.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl"
                  />
                </div>
              </div>
              <!-- Slide 3 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide"
              >
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div
                    class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]"
                  >
                    <h3 class="text-xl md:text-3xl font-semibold">
                      AI-Powered Digital Twin
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        Intellivon partnered with a leading manufacturing enterprise to implement AI-powered Digital Twin technology, enabling real-time simulation of manufacturing processes. Our Digital Product Engineering Services helped optimize operations, enhance production accuracy, and predict maintenance needs.
                      </p>
                      <p
                        class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm"
                      >
                        Intellivon partnered with a leading manufacturing enterprise to implement AI-powered Digital Twin technology, enabling real-time simulation of manufacturing processes. Our Digital Product Engineering Services helped optimize operations, enhance production accuracy, and predict maintenance needs.
                      </p>
                      <button
                        class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden"
                      >
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      Improved production efficiency by
                      <span class="xl:text-xl font-semibold">25% </span>
                    </li>
                    <li class="">
                      Reduced maintenance costs by
                      <span class="xl:text-xl font-semibold">20%</span>
                    </li>
                    <li class="">
                      Increased asset utilization by
                      <span class="xl:text-xl font-semibold">15% </span>
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a
                    href="https://intellivon.com/ai-strategy-call-booking-confirmation/"
                    target="_blank"
                  >
                    <div
                      class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button"
                    >
                      Explore more
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="25"
                        viewBox="0 0 24 25"
                        fill="none"
                      >
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                  </a>
                </div>
                <div
                  class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl"
                >
                  <img
                    src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-3.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl"
                  />
                </div>
              </div>
              <!-- Slide 4 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide"
              >
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div
                    class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]"
                  >
                    <h3 class="text-xl md:text-3xl font-semibold">
                      AI-Driven Product and Platform Engineering
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        We partnered with a leading smart infrastructure provider to modernize their legacy systems and enhance their IoT-based platform. By leveraging cloud-native development and microservices architecture, we helped build a scalable and adaptable platform capable of managing real-time data from smart city sensors, improving operational efficiency, and enabling future scalability.
                      </p>
                      <p
                        class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm"
                      >
                        We partnered with a leading smart infrastructure provider to modernize their legacy systems and enhance their IoT-based platform. By leveraging cloud-native development and microservices architecture, we helped build a scalable and adaptable platform capable of managing real-time data from smart city sensors, improving operational efficiency, and enabling future scalability.
                      </p>
                      <button
                        class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden"
                      >
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      <span class="xl:text-xl font-semibold">40% </span>
                      increase in platform scalability
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">30% </span>
                      faster deployment times
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold"></span>
                      Enhanced operational efficiency 
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a
                    href="https://intellivon.com/ai-strategy-call-booking-confirmation/"
                    target="_blank"
                  >
                    <div
                      class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button"
                    >
                      Explore more
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="25"
                        viewBox="0 0 24 25"
                        fill="none"
                      >
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                  </a>
                </div>
                <div
                  class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl"
                >
                  <img
                    src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-4.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl"
                  />
                </div>
              </div>
              <!-- Slide 5 -->
              <div
                class="swiper-slide w-full h-[500px] shrink-0 flex flex-col lg:flex-row rounded-xl shadow-purple bg-white case-study-slide"
              >
                <div class="w-full lg:w-1/2 flex flex-col gap-5 px-5 py-4">
                  <div
                    class="flex flex-col w-full gap-2 pb-4 border-b border-b-[#99899d]"
                  >
                    <h3 class="text-xl md:text-3xl font-semibold">
                      Architecture Advisory for Defence Contractor
                    </h3>
                    <div class="text-[#333] leading-7 tracking-wide">
                      <p class="hidden xl:block text-md">
                        We worked with a prominent defense contractor to optimize their technology infrastructure. By conducting an architecture audit and providing enterprise platform strategy consulting, we ensured their systems were robust and capable of handling sensitive data while meeting compliance requirements.
                      </p>
                      <p
                        class="xl:hidden leading-0 line-clamp-5 read-more-content text-sm"
                      >
                        We worked with a prominent defense contractor to optimize their technology infrastructure. By conducting an architecture audit and providing enterprise platform strategy consulting, we ensured their systems were robust and capable of handling sensitive data while meeting compliance requirements.
                      </p>
                      <button
                        class="read-more-toggle text-sm text-[#7C3BAF] mt-2 xl:hidden"
                      >
                        Read More
                      </button>
                    </div>
                  </div>
                  <ul class="flex flex-col gap-2 list-disc pl-5">
                    <li class="">
                      <span class="xl:text-xl font-semibold">50%</span>
                      reduction in system downtime
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold">40%</span>
                      faster compliance checks
                    </li>
                    <li class="">
                      <span class="xl:text-xl font-semibold"></span>
                      Improved data security
                    </li>
                  </ul>
                  <!-- Explore More button -->
                  <a
                    href="https://intellivon.com/ai-strategy-call-booking-confirmation/"
                    target="_blank"
                  >
                    <div
                      class="flex gap-5 py-2 px-5 items-center bg-[#28103B] text-white rounded-full w-fit"
                      role="button"
                    >
                      Explore more
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="25"
                        viewBox="0 0 24 25"
                        fill="none"
                      >
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                  </a>
                </div>
                <div
                  class="hidden lg:block w-full lg:w-1/2 h-[500px] overflow-hidden rounded-r-xl"
                >
                  <img
                    src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/case-study-5.webp"
                    class="w-full h-full object-center mask-top rounded-r-xl"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Dots -->
      <div
        id="case-study-dots"
        class="flex flex-wrap gap-2 items-center justify-center mt-5 mx-auto"
      >
        <div
          class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 70px; opacity: 1"
        ></div>
        <div
          class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 28px; opacity: 0.5"
        ></div>
        <div
          class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 20px; opacity: 0.5"
        ></div>
        <div
          class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 20px; opacity: 0.5"
        ></div>
        <div
          class="h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300"
          style="width: 20px; opacity: 0.5"
        ></div>
      </div>
      <!-- Button -->
      <a
        class="m-auto my-5 rounded-full bg-white flex gap-3 w-fit p-3 z-20 outline-gradient"
        href="https://intellivon.com/portfolio/"
        target="_blank"
      >
        <div>View more Projects</div>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="25"
          viewBox="0 0 24 25"
          fill="none"
        >
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M11.9999 22.1004C14.546 22.1004 16.9878 21.089 18.7881 19.2886C20.5885 17.4883 21.5999 15.0465 21.5999 12.5004C21.5999 9.95431 20.5885 7.51252 18.7881 5.71217C16.9878 3.91182 14.546 2.90039 11.9999 2.90039C9.45382 2.90039 7.01203 3.91182 5.21168 5.71217C3.41133 7.51252 2.3999 9.95431 2.3999 12.5004C2.3999 15.0465 3.41133 17.4883 5.21168 19.2886C7.01203 21.089 9.45382 22.1004 11.9999 22.1004ZM8.0999 11.6004C7.86121 11.6004 7.63229 11.6952 7.46351 11.864C7.29472 12.0328 7.1999 12.2617 7.1999 12.5004C7.1999 12.7391 7.29472 12.968 7.46351 13.1368C7.63229 13.3056 7.86121 13.4004 8.0999 13.4004H13.6079L11.0879 15.7404C10.9129 15.9027 10.8095 16.1279 10.8005 16.3665C10.7915 16.605 10.8776 16.8373 11.0399 17.0124C11.2022 17.1874 11.4274 17.2908 11.666 17.2998C11.9045 17.3088 12.1369 17.2227 12.3119 17.0604L16.5119 13.1604C16.6028 13.0761 16.6753 12.974 16.7249 12.8605C16.7744 12.7469 16.8 12.6243 16.8 12.5004C16.8 12.3765 16.7744 12.2539 16.7249 12.1403C16.6753 12.0267 16.6028 11.9246 16.5119 11.8404L12.3119 7.94039C12.2252 7.86002 12.1236 7.79751 12.0127 7.75643C11.9019 7.71534 11.7841 7.69649 11.666 7.70095C11.4274 7.70995 11.2022 7.81335 11.0399 7.98839C10.8776 8.16343 10.7915 8.39579 10.8005 8.63433C10.8095 8.87288 10.9129 9.09808 11.0879 9.26039L13.6079 11.6004H8.0999Z"
            fill="url(#paint0_linear_2_494)"
          />
          <defs>
            <linearGradient
              id="paint0_linear_2_494"
              x1="6.5"
              y1="7"
              x2="22"
              y2="13"
              gradientUnits="userSpaceOnUse"
            >
              <stop stop-color="#7C3BAF" />
              <stop offset="1" stop-color="#E61C42" />
            </linearGradient>
          </defs>
        </svg>
      </a>
    </div>
  </div>

  <!-- Custom Swiper Logic -->
  <script>
    const csSwiper = new Swiper(".swiper-case-study", {
      slidesPerView: 1,
      slidesPerGroup: 1,
      spaceBetween: 10,
      loop: true,
      autoplay: {
        delay: 3000, //  3 seconds
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: "#custom-cs-next",
        prevEl: "#custom-cs-prev",
      },
      centeredSlides: false,
      centeredSlidesBounds: true,
      breakpoints: {
        0: {
          slidesPerView: 1,
          slidesPerGroup: 1,
        },
        768: {
          slidesPerView: 1,
          slidesPerGroup: 1,
        },
        1024: {
          slidesPerView: 1,
          slidesPerGroup: 1,
        },
      },
    });

    // Pause the slider on hover
    const slides = document.querySelectorAll(".swiper-slide");
    slides.forEach((slide) => {
      slide.addEventListener("mouseenter", () => {
        csSwiper.autoplay.stop(); // Stop autoplay on hover
      });

      slide.addEventListener("mouseleave", () => {
        csSwiper.autoplay.start(); // Resume autoplay when hover is removed
      });
    });

    // Update the active dot on slide change
    csSwiper.on("slideChange", function () {
      const dots = document.querySelectorAll("#case-study-dots div");
      dots.forEach((dot, index) => {
        if (index === csSwiper.realIndex) {
          dot.style.width = "70px";
          dot.style.opacity = "1";
        } else {
          dot.style.width = "28px";
          dot.style.opacity = "0.5";
        }
      });
    });
  </script>
</section>

<!-- USECASES -->
<section
  class="w-full px-5 lg:px-10 py-14 lg:py-20 bg-[#F2F7FF] relative overflow-hidden"
>
  <div class="container flex flex-col gap-5 items-center">
    <!-- Heading -->
    <div class="w-full">
      <div class="text-md font-semibold text-[#656565]">USECASES</div>
      <h2
        class="w-full lg:w-11/12 text-4xl gap-3 font-bold text-black1 font-urbanist leading-snug tracking-[0.5px]"
      >
        <span class="text-gradient">
          Driving Results Key Use Cases Across Industries
        </span>
      </h2>
    </div>

    <!-- Slider with custom arrows -->
    <div class="flex justify-evenly items-center gap-2 md:gap-5 w-full">
      <!-- Prev Button -->
      <div class="cursor-pointer" id="custom-prev">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 30 30"
          fill="none"
          class="rotate-180"
        >
          <rect
            width="30"
            height="30"
            rx="15"
            fill="url(#paint0_linear_217_524)"
          />
          <path
            d="M12.5 8.75L18.75 15L12.5 21.25"
            stroke="white"
            stroke-width="3"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <defs>
            <linearGradient
              id="paint0_linear_217_524"
              x1="8.5"
              y1="4"
              x2="25.5"
              y2="30"
              gradientUnits="userSpaceOnUse"
            >
              <stop stop-color="#7C3BAF" />
              <stop offset="1" stop-color="#E61C42" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <!-- Swiper Wrapper -->
      <div class="swiper swiper-usecases w-full">
        <div class="swiper-wrapper">
          <!-- CARD 1 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]"
            >
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  QA-as-a-Service
                </h3>
              </div>
              <p class="text-center md:text-start">
                Accelerate your release cycles and ensure top-tier product quality with Intellivon’s flexible QA-as-a-service. We offer test automation, performance engineering, regression testing, and integrated quality oversight, seamlessly aligning with your CI/CD pipelines and agile workflows to deliver fast, reliable, and robust products.
              </p>
            </div>
          </div>

          <!-- CARD 2 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]"
            >
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  Ongoing Product Maintenance & Growth
                </h3>
              </div>
              <p class="text-center md:text-start">
                Keep your digital platforms competitive and reliable with Intellivon’s managed product sustenance. Our team handles version upgrades, reduces technical debt, performs performance tuning, and provides ongoing support for both legacy and modern tech stacks, ensuring your solutions evolve with your business needs.
              </p>
            </div>
          </div>

          <!-- CARD 3 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]"
            >
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  Engineering Vendor Consolidation
                </h3>
              </div>
              <p class="text-center md:text-start">
                Simplify operations and boost release velocity by consolidating your engineering vendors with Intellivon. We streamline coordination, improve consistency, and ensure greater accountability across your entire product portfolio, providing a single trusted partner for your digital solutions.
              </p>
            </div>
          </div>
          <!-- CARD 4 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]"
            >
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  Build-Operate-Transfer (BOT)
                </h3>
              </div>
              <p class="text-center md:text-start">
                Scale your digital product teams swiftly while maintaining full control over intellectual property with Intellivon’s Build-Operate-Transfer model. We assemble and operate dedicated teams tailored to your needs, then transition them to your ownership, ensuring seamless handover and long-term success without losing momentum.
              </p>
            </div>
          </div>

          <!-- CARD 5 -->
          <div class="swiper-slide h-full">
            <div
              class="flex flex-col gap-5 py-5 px-3 bg-white rounded-2xl border border-[#333333] h-[450px] md:h-[320px] lg:h-[240px]"
            >
              <div class="flex flex-col md:flex-row gap-5 items-center">
                <!-- SVG Icon -->

                <h3 class="font-bold text-lg text-center md:text-start">
                  Expert Engineering Staff Augmentation
                </h3>
              </div>
              <p class="text-center md:text-start">
                Enhance your internal teams with Intellivon’s expert engineering talent, bringing architectural expertise, DevOps maturity, and QA leadership to accelerate delivery. Our professionals help elevate your technical standards, drive innovation, and seamlessly integrate with your team to meet evolving business demands.
              </p>
            </div>
          </div>

        </div>
      </div>

      <!-- Next Button -->
      <div class="cursor-pointer" id="custom-next">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="40"
          height="40"
          viewBox="0 0 30 30"
          fill="none"
        >
          <rect
            width="30"
            height="30"
            rx="15"
            fill="url(#paint0_linear_217_524)"
          />
          <path
            d="M12.5 8.75L18.75 15L12.5 21.25"
            stroke="white"
            stroke-width="3"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <defs>
            <linearGradient
              id="paint0_linear_217_524"
              x1="8.5"
              y1="4"
              x2="25.5"
              y2="30"
              gradientUnits="userSpaceOnUse"
            >
              <stop stop-color="#7C3BAF" />
              <stop offset="1" stop-color="#E61C42" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    </div>
  </div>

  <!-- Background Decoration (same as before) -->
  <div
    class="absolute bottom-0 right-0 w-[320px] h-[421px] overflow-hidden pointer-events-none"
  >
    <!-- Your SVG here -->
  </div>
  <div
    class="absolute bottom-2 left-[5%] w-[1257px] h-[421px] overflow-hidden pointer-events-none"
  >
    <!-- Your SVG here -->
  </div>

  <!-- Custom Swiper Logic -->
  <script>
    const swiper = new Swiper(".swiper-usecases", {
      slidesPerView: 3,
      slidesPerGroup: 3,
      spaceBetween: 20,
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: "#custom-next",
        prevEl: "#custom-prev",
      },
      centeredSlides: false,
      centeredSlidesBounds: true, // ✅ Key to center-align last group if fewer than 3
      breakpoints: {
        0: {
          slidesPerView: 1,
          slidesPerGroup: 1,
        },
        768: {
          slidesPerView: 2,
          slidesPerGroup: 2,
        },
        1024: {
          slidesPerView: 3,
          slidesPerGroup: 1,
        },
      },
    });
  </script>
</section>

<!-- WHY CHOOSE US -->
<section class="py-24 w-full bg-cover px-5 lg:px-10 relative overflow-hidden">
  <div class="container">
    <div class="flex items-end justify-between mt-6 mb-3 w-full">
      <div class="w-full">
        <div class="w-full flex flex-col gap-5 items-start">
          <div class="text-md font-semibold text-[#656565]">WHY CHOOSE US</div>
          <div class="flex flex-col gap-5 lg:gap-0 lg:flex-row justify-between">
            <h2
              class="w-full lg:w-7/12 text-4xl flex-wrap gap-3 flex items-center font-bold text-black1 font-urbanist"
            >
              Why Choose Intellivon for 
              <span class="text-gradient">Digital Product Engineering</span>
            </h2>
            <a
              href="https://intellivon.com/ai-strategy-call-booking-confirmation/"
              target="_blank"
            >
              <div>
                <button
                  type="button"
                  class="relative px-3 py-3 text-white font-medium rounded-full bg-white overflow-hidden group"
                >
                  <span
                    class="relative z-10 text-blue text-nowrap text-sm lg:text-md items-center lg:items-normal flex gap-2"
                  >
                    Know More About Our Capabilities
                    <img
                      src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/know-more-capabilities-arrow.svg"
                    />
                  </span>
                  <div
                    class="absolute inset-0 bg-gradient-to-l from-[#ab00ff] via-[#7000eb] to-[#00c8eb] rounded-full p-[1px]"
                  >
                    <div class="h-full w-full bg-white rounded-full"></div>
                  </div>
                </button>
              </div>
            </a>
          </div>
          <p class="text-grey1 text-base font-medium">
            We co-engineer digital products that transform how businesses operate, compete, and grow. With a decade-long track record, deep technical expertise, and a collaborative mindset, Intellivon is your trusted partner for turning vision into scalable, future-ready products.
          </p>
        </div>
      </div>
    </div>
    <div class="mt-16 grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
      <!-- Card 1 -->
      <div
        class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10"
      >
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div
            class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center"
          >
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Product Engineering Expertise
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800"
          >
            <!-- SVG Icon -->

            <p class="text-sm">
              With 11+ years of experience in product engineering and deploying 1000 digital products, our team brings deep technical expertise to every project. 
            </p>
          </div>
        </div>
      </div>
      <!-- Card 2 -->
      <div
        class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10"
      >
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div
            class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center"
          >
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Cloud-Native & MACH Expertise
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800"
          >
            <!-- SVG Icon -->

            <p class="text-sm">
              Our cloud-native and MACH (Microservices, API-first, Cloud-native, and Headless) expertise ensures that your digital products are built for scalability, flexibility, and rapid growth. 
            </p>
          </div>
        </div>
      </div>
      <!-- Card 3 -->
      <div
        class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10"
      >
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div
            class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center"
          >
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">Collaborative Engineering</h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800"
          >
            <!-- SVG Icon -->

            <p class="text-sm">
              We believe in building strong partnerships with our clients. Our collaborative engineering approach ensures your product team is actively involved throughout the development process.
            </p>
          </div>
        </div>
      </div>
      <!-- Card 4 -->
      <div
        class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10"
      >
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div
            class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center"
          >
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Advanced Engineering Tech
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800"
          >
            <!-- SVG Icon -->

            <p class="text-sm">
              Leveraging the latest and most advanced technologies, our engineering stack ensures high performance and security. 
            </p>
          </div>
        </div>
      </div>

      <!-- Card 5 -->
      <div
        class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10"
      >
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div
            class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center"
          >
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Flexible Partnership Model
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800"
          >
            <!-- SVG Icon -->

            <p class="text-sm">
              Our flexible partnership model adapts to your specific needs, whether you require end-to-end development, focused expertise, or ongoing support.
            </p>
          </div>
        </div>
      </div>

      <!-- Card 6 -->
      <div
        class="choose-card-wrapper w-full h-[212px] md:w-[409px] m-auto lg:m-0 z-10"
      >
        <div class="choose-card shadow-[0_24px_34px_0_rgba(0,0,0,.078)]">
          <!-- Front Side -->
          <div
            class="choose-card-front bg-white p-6 flex flex-col gap-8 items-center justify-center"
          >
            <!-- SVG Icon -->

            <h3 class="text-xl font-semibold text-center">
              Accelerated Time-to-Market
            </h3>
          </div>
          <!-- Back Side -->
          <div
            class="choose-card-back bg-white p-6 flex flex-col gap-4 items-center justify-center text-center text-gray-800"
          >
            <!-- SVG Icon -->

            <p class="text-sm">
              We streamline product development with agile methodologies and automation, helping you launch innovative digital products faster and stay ahead in dynamic markets.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Background Decoration -->
  <div
    class="absolute right-0 top-0 w-[468px] h-[634px] overflow-hidden pointer-events-none"
  >
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="468"
      height="634"
      viewBox="0 0 468 634"
      fill="none"
    >
      <g filter="url(#filter0_f_47_15221)">
        <path
          d="M564 197C564 126.86 507.14 70 437 70C366.86 70 310 126.86 310 197C310 267.14 366.86 324 437 324C507.14 324 564 267.14 564 197Z"
          fill="#7C3BAF"
        />
      </g>
      <defs>
        <filter
          id="filter0_f_47_15221"
          x="0.200012"
          y="-239.8"
          width="873.6"
          height="873.6"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="BackgroundImageFix"
            result="shape"
          />
          <feGaussianBlur
            stdDeviation="154.9"
            result="effect1_foregroundBlur_47_15221"
          />
        </filter>
      </defs>
    </svg>
  </div>
  <div
    class="absolute left-0 top-[30%] w-[407px] h-[823px] overflow-hidden pointer-events-none"
  >
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="407"
      height="823"
      viewBox="0 0 407 823"
      fill="none"
    >
      <g filter="url(#filter0_f_47_15222)">
        <path
          d="M97 437C97 366.86 40.1402 310 -30 310C-100.14 310 -157 366.86 -157 437C-157 507.14 -100.14 564 -30 564C40.1402 564 97 507.14 97 437Z"
          fill="#E61C42"
          fill-opacity="0.6"
        />
      </g>
      <defs>
        <filter
          id="filter0_f_47_15222"
          x="-466.8"
          y="0.200012"
          width="873.6"
          height="873.6"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="BackgroundImageFix"
            result="shape"
          />
          <feGaussianBlur
            stdDeviation="154.9"
            result="effect1_foregroundBlur_47_15222"
          />
        </filter>
      </defs>
    </svg>
  </div>
  <div
    class="hidden lg:block absolute left-[30%] top-[30%] w-[821px] h-[744px] overflow-hidden pointer-events-none"
  >
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="821"
      height="744"
      viewBox="0 0 821 744"
      fill="none"
      class="w-max-20"
    >
      <g filter="url(#filter0_f_47_15226)">
        <path
          d="M511 410.5C511 354.995 466.005 310 410.5 310C354.995 310 310 354.995 310 410.5C310 466.005 354.995 511 410.5 511C466.005 511 511 466.005 511 410.5Z"
          fill="#E61C42"
        />
      </g>
      <defs>
        <filter
          id="filter0_f_47_15226"
          x="0.200012"
          y="0.200012"
          width="820.6"
          height="820.6"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="BackgroundImageFix"
            result="shape"
          />
          <feGaussianBlur
            stdDeviation="154.9"
            result="effect1_foregroundBlur_47_15226"
          />
        </filter>
      </defs>
    </svg>
  </div>
</section>

<!-- HOME COUNTS -->
<div
  class="bg-gradient-to-l from-[#E61C42] to-[#61268F] lg:py-12 py-10 relative max-w-full overflow-hidden"
>
  <div class="container grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
    <!-- Count Item 1 -->
    <div class="flex flex-col items-center px-5">
      <h3
        class="text-medium font-bold text-white font-urbanist my-3 text-center"
      >
        500+
      </h3>
      <h3 class="text-xl font-normal text-white text-center">
        Successful AI-driven projects
      </h3>
    </div>
    <!-- Count Item 2 -->
    <div class="flex flex-col items-center px-5">
      <h3
        class="text-medium font-bold text-white font-urbanist my-3 text-center"
      >
        11+
      </h3>
      <h3 class="text-xl font-normal text-white text-center">
        Year of expertise in delivering AI Solutions
      </h3>
    </div>
    <!-- Count Item 3 -->
    <div class="flex flex-col items-center px-5">
      <h3
        class="text-medium font-bold text-white font-urbanist my-3 text-center"
      >
        40+
      </h3>
      <h3 class="text-xl font-normal text-white text-center">
        AI, ML, and data tools mastered
      </h3>
    </div>
    <!-- Count Item 4 -->
    <div class="flex flex-col items-center px-10">
      <h3
        class="text-medium font-bold text-white font-urbanist my-3 text-center"
      >
        200+
      </h3>
      <h3 class="text-xl font-normal text-white text-center px-5">
        Dedicated AI experts
      </h3>
    </div>
  </div>
  <div
    class="absolute top-0 left-0 max-w-[288px] max-h-[187px] overflow-hidden pointer-events-none"
  >
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="288"
      height="187"
      viewBox="0 0 288 187"
      fill="none"
    >
      <path
        opacity="0.6"
        d="M-6.00009 77.3586C14.732 155.567 96.0211 201.874 175.564 180.788C255.107 159.702 302.783 79.2084 282.051 0.999952"
        stroke="#9A9A9A"
      />
    </svg>
  </div>
  <div
    class="absolute bottom-0 left-[50%] max-w-[315px] max-h-[137px] overflow-hidden pointer-events-none"
  >
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="315"
      height="137"
      viewBox="0 0 315 137"
      fill="none"
    >
      <path
        opacity="0.4"
        d="M313.975 150.186C313.975 67.7929 243.913 1 157.487 1C71.0618 1 1 67.7929 1 150.186"
        stroke="#9A9A9A"
      />
    </svg>
  </div>
  <div
    class="absolute top-0 right-0 max-w-[300px] max-h-[190px] overflow-hidden pointer-events-none"
  >
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="300"
      height="190"
      viewBox="0 0 300 190"
      fill="none"
    >
      <path
        opacity="0.5"
        d="M5.38462 0.521899C-15.527 80.374 33.3583 162.348 114.573 183.617C195.788 204.885 278.578 157.394 299.489 77.5419"
        stroke="#9A9A9A"
      />
    </svg>
  </div>
</div>

<!-- POWERED TECHNOLOGIES -->
<section class="bg-powered py-16 lg:py-24 bg-cover bg-no-repeat px-5 lg:px-10">
  <div class="container">
    <!-- Heading -->
    <div class="w-full flex flex-col gap-3 items-start">
      <div class="text-md font-semibold text-[#656565]">TECHNOLOGY WE USE</div>
      <h2
        class="text-4xl font-bold text-black1 font-urbanist leading-snug tracking-[0.5px] w-full md:gap-3"
      >
        Our Digital Product Engineering 
        <span class="text-gradient"> Tech Stack</span>
      </h2>
      <div class="w-full flex flex-col lg:flex-row justify-between">
        <p
          class="capitalize mb-4 md:mb-0 text-base font-medium text-grey1 mt-2 md:w-8/12 tracking-[0.25px] pr-5"
        >
          Our expert data engineers leverage advanced technologies, including AWS, Kubernetes, and machine learning, to help you deliver enterprise-grade digital products, enabling your business to scale seamlessly and consistently.
        </p>
        <!-- Buttons -->
        <div class="flex gap-2 mt-8 lg:mt-0">
          <div class="cursor-pointer" id="custom-tech-prev">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="40"
              height="40"
              viewBox="0 0 30 30"
              fill="none"
              class="rotate-180"
            >
              <rect
                width="30"
                height="30"
                rx="15"
                fill="url(#paint0_linear_217_524)"
              />
              <path
                d="M12.5 8.75L18.75 15L12.5 21.25"
                stroke="white"
                stroke-width="3"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <defs>
                <linearGradient
                  id="paint0_linear_217_524"
                  x1="8.5"
                  y1="4"
                  x2="25.5"
                  y2="30"
                  gradientUnits="userSpaceOnUse"
                >
                  <stop stop-color="#7C3BAF" />
                  <stop offset="1" stop-color="#E61C42" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <div class="cursor-pointer" id="custom-tech-next">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="40"
              height="40"
              viewBox="0 0 30 30"
              fill="none"
            >
              <rect
                width="30"
                height="30"
                rx="15"
                fill="url(#paint0_linear_217_524)"
              />
              <path
                d="M12.5 8.75L18.75 15L12.5 21.25"
                stroke="white"
                stroke-width="3"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <defs>
                <linearGradient
                  id="paint0_linear_217_524"
                  x1="8.5"
                  y1="4"
                  x2="25.5"
                  y2="30"
                  gradientUnits="userSpaceOnUse"
                >
                  <stop stop-color="#7C3BAF" />
                  <stop offset="1" stop-color="#E61C42" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>
    </div>
    <!-- Swiper Carousel -->
    <div class="mt-10">
      <!-- Custom Navigation Buttons outside the swiper box -->
      <div class="swiper techSwiper">
        <div class="swiper-wrapper min-h-auto">
          <!-- Slide 1:  -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Cloud & Infrastructure
              </h3>
              <div
                class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto"
              >
                <!-- Repeat these card blocks -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    AWS
                    
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google Cloud Platform (GCP)
                  </h4>
                </div>
                <div class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Microsoft Azure
                  </h4>
                </div>
                <div class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Docker
                  </h4>
                </div>
                <div class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm">
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Kubernetes
                  </h4>
                </div>
              </div>
            </div>
          </div>
          <!-- Slide 2: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Backend & Software Engineering
              </h3>
              <div
                class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto"
              >
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Node.js
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Python
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Java
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Ruby on Rails
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Spring Boot
                  </h4>
                </div>

              
              </div>
            </div>
          </div>
          <!-- Slide 3: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Frontend & User Interface
              </h3>
              <div
                class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto"
              >
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    React.js
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Vue.js
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Angular
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Sass                    
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    HTML5/CSS3                    
                  </h4>
                </div>
              </div>
            </div>
          </div>
          <!-- Slide 4: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Data Engineering & Analytics
              </h3>
              <div
                class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto"
              >
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Apache Kafka
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Apache Spark
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Elasticsearch
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    AWS Redshift
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- SVG -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Google BigQuery
                  </h4>
                </div>
              </div>
            </div>
          </div>
          <!-- Slide 5: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Database & Storage Solutions
              </h3>
              <div
                class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto"
              >
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    MongoDB
                    <span class="text-[12px] font-normal text-black2 block"></span>
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    PostgreSQL
                    <span class="text-[12px] font-normal text-black2 block"></span>
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    MySQL
                    <span class="text-[12px] font-normal text-black2 block"></span>
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Cassandra
                    <span class="text-[12px] font-normal text-black2 block"></span>
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Amazon S3
                    <span class="text-[12px] font-normal text-black2 block"></span>
                  </h4>
                </div>

              </div>
            </div>
          </div>
          <!-- Slide 6: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                AI & Machine Learning
              </h3>
              <div
                class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto"
              >
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    TensorFlow
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    PyTorch
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    AWS SageMaker
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Scikit-learn
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Keras
                  </h4>
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 7: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                DevOps & Automation
              </h3>
              <div
                class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto"
              >
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Jenkins
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Ansible
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    Terraform
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    GitLab CI
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    CircleCI
                  </h4>
                </div>
                
              </div>
            </div>
          </div>

          <!-- Slide 8: -->
          <div class="swiper-slide border-2 border-[#99899d] rounded-[30px]">
            <div class="flex flex-col w-full items-center gap-5 py-10 lg:py-20">
              <h3 class="font-bold text-3xl text-center">
                Security & Compliance
              </h3>
              <div
                class="flex flex-wrap justify-center gap-6 mt-5 max-w-[1200px] mx-auto"
              >
                <!-- Use same layout -->
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    OAuth
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    JWT (JSON Web Tokens)
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    SSL/TLS
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    HashiCorp Vault
                  </h4>
                </div>
                <div
                  class="technology-edge w-[260px] lg:w-[280px] rounded-full flex items-center gap-3 px-6 py-3 bg-white shadow-sm"
                >
                  <!-- svg -->
                  <h4 class="text-base md:text-xl font-medium text-black2">
                    AWS IAM
                  </h4>
                </div>


              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Powered Technologies Script -->
  <script>
    document.addEventListener("DOMContentLoaded", () => {
      // Initialize Swiper 11 with navigation disabled (we'll use custom buttons)
      const swiper = new Swiper(".techSwiper", {
        loop: true,
        speed: 200,
        autoplay: {
          delay: 2000,
          disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: false, // disable default arrows
      });

      // Attach event listeners to custom buttons
      const prevBtn = document.getElementById("custom-tech-prev");
      const nextBtn = document.getElementById("custom-tech-next");

      prevBtn.addEventListener("click", () => swiper.slidePrev());
      nextBtn.addEventListener("click", () => swiper.slideNext());
    });
  </script>
</section>

<!-- TESTIMONIALS SECTION -->
<section>
  <div class="bg-white bg-cover relative overflow-hidden px-5 lg:px-10 py-12">
    <!-- Background Decoration -->
    <div
      class="absolute left-0 top-[10%] max-w-[403px] max-h-fit verflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="403"
        height="576"
        viewBox="0 0 403 576"
        fill="none"
      >
        <g filter="url(#filter0_f_2_589)">
          <path
            d="M203 339.5C203 418.201 138.977 482 60 482C-18.9767 482 -83 418.201 -83 339.5C-83 260.799 -18.9767 197 60 197C138.977 197 203 260.799 203 339.5Z"
            fill="#E61C42"
            fill-opacity="0.2"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_2_589"
            x="-283"
            y="-3"
            width="686"
            height="685"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="100"
              result="effect1_foregroundBlur_2_589"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div
      class="absolute left-[20%] top-[10%] max-w-[686px] max-h-[534px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="686"
        height="534"
        viewBox="0 0 686 534"
        fill="none"
      >
        <g filter="url(#filter0_f_2_591)">
          <path
            d="M486 342.5C486 421.201 421.977 485 343 485C264.023 485 200 421.201 200 342.5C200 263.799 264.023 200 343 200C421.977 200 486 263.799 486 342.5Z"
            fill="#7C3BAF"
            fill-opacity="0.3"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_2_591"
            x="0"
            y="0"
            width="686"
            height="685"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="100"
              result="effect1_foregroundBlur_2_591"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div
      class="absolute left-[25%] top-[10%] max-w-[686px] max-h-[534px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="686"
        height="576"
        viewBox="0 0 686 576"
        fill="none"
      >
        <g filter="url(#filter0_f_2_590)">
          <path
            d="M486 316.5C486 395.201 421.977 459 343 459C264.023 459 200 395.201 200 316.5C200 237.799 264.023 174 343 174C421.977 174 486 237.799 486 316.5Z"
            fill="#E61C42"
            fill-opacity="0.3"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_2_590"
            x="0"
            y="-26"
            width="686"
            height="685"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="100"
              result="effect1_foregroundBlur_2_590"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div
      class="absolute right-0 top-24 max-w-[449px] max-h-fit overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="449"
        height="556"
        viewBox="0 0 449 556"
        fill="none"
      >
        <g filter="url(#filter0_f_2_592)">
          <path
            d="M486 342.5C486 421.201 421.977 485 343 485C264.023 485 200 421.201 200 342.5C200 263.799 264.023 200 343 200C421.977 200 486 263.799 486 342.5Z"
            fill="#7C3BAF"
            fill-opacity="0.4"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_2_592"
            x="0"
            y="0"
            width="686"
            height="685"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="100"
              result="effect1_foregroundBlur_2_592"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div class="container">
      <div class="flex items-end justify-between mt-6 mb-3">
        <div class="w-full flex flex-col gap-5">
          <!-- Section Heading -->
          <div class="text-md font-semibold text-[#656565]">
            TESTIMONIAL SECTION
          </div>
          <div
            class="flex flex-col gap-5 lg:gap-0 lg:flex-row justify-between w-full"
          >
            <h2 class="w-full lg:w-11/12 text-4xl gap-3 font-bold text-black1 font-urbanist leading-snug tracking-[0.5px]">
              <span class="text-gradient">What Our Clients Say About Us</span>
            </h2>
            <div class="flex gap-2 z-50 mt-8 lg:mt-0">
              <!-- Prev -->
              <svg
                id="testimonial-prev"
                xmlns="http://www.w3.org/2000/svg"
                width="50"
                height="50"
                viewBox="0 0 50 50"
                fill="none"
                class="cursor-pointer"
              >
                <mask
                  id="mask-prev"
                  maskUnits="userSpaceOnUse"
                  x="1"
                  y="1"
                  width="48"
                  height="48"
                >
                  <path
                    d="M25 4.17C13.49 4.17 4.17 13.49 4.17 25C4.17 36.51 13.49 45.83 25 45.83C36.51 45.83 45.83 36.51 45.83 25C45.83 13.49 36.51 4.17 25 4.17Z"
                    fill="white"
                    stroke="white"
                    stroke-width="5.33"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M28.13 15.63L18.75 25L28.13 34.38"
                    stroke="black"
                    stroke-width="5.33"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </mask>
                <g mask="url(#mask-prev)">
                  <path d="M50 50H0V0H50V50Z" fill="url(#paint-prev)" />
                </g>
                <defs>
                  <linearGradient
                    id="paint-prev"
                    x1="50"
                    y1="25"
                    x2="-7.5"
                    y2="25"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#7C3BAF" />
                    <stop offset="1" stop-color="#E61C42" />
                  </linearGradient>
                </defs>
              </svg>
              <!-- Next -->
              <svg
                id="testimonial-next"
                xmlns="http://www.w3.org/2000/svg"
                width="50"
                height="50"
                viewBox="0 0 50 50"
                fill="none"
                class="cursor-pointer"
              >
                <mask
                  id="mask-next"
                  maskUnits="userSpaceOnUse"
                  x="1"
                  y="1"
                  width="48"
                  height="48"
                >
                  <path
                    d="M25 45.83C36.51 45.83 45.83 36.51 45.83 25C45.83 13.49 36.51 4.17 25 4.17C13.49 4.17 4.17 13.49 4.17 25C4.17 36.51 13.49 45.83 25 45.83Z"
                    fill="white"
                    stroke="white"
                    stroke-width="5.33"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M21.88 34.38L31.25 25L21.88 15.63"
                    stroke="black"
                    stroke-width="5.33"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </mask>
                <g mask="url(#mask-next)">
                  <path d="M0 0H50V50H0V0Z" fill="url(#paint-next)" />
                </g>
                <defs>
                  <linearGradient
                    id="paint-next"
                    x1="5"
                    y1="31"
                    x2="62"
                    y2="32"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#7C3BAF" />
                    <stop offset="1" stop-color="#E61C42" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div class="mt-16 grid grid-cols-1 lg:grid-cols-2 gap-14 lg:gap-10">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5 order-2 lg:order-1">
          <div class="common-whitebox2 p-6 rounded-lg shadow-lg h-44">
            <h3 class="text-5xl font-normal font-urbanist text-gradient2">
              50
              <span class="text-2xl"> % </span>
            </h3>
            <p class="text-xl font-medium text-black1 font-urbanist mt-8 pr-5">
              Faster modernization cycle
            </p>
          </div>
          <div class="common-whitebox2 p-6 rounded-lg shadow-lg h-44">
            <h3 class="text-5xl font-normal font-urbanist text-gradient2">
              30 - 40
              <span class="text-2xl"> % </span>
            </h3>
            <p class="text-xl font-medium text-black1 font-urbanist mt-8">
              Lower engineering costs
            </p>
          </div>
          <div class="common-whitebox2 p-6 rounded-lg shadow-lg h-44">
            <h3 class="text-5xl font-normal font-urbanist text-gradient2">
              80
              <span class="text-2xl"> % </span>
            </h3>
            <p class="text-xl font-medium text-black1 font-urbanist mt-8">
              Fewer bugs and reworks
            </p>
          </div>
          <div class="common-whitebox2 p-6 rounded-lg shadow-lg h-44">
            <h3 class="text-5xl font-normal font-urbanist text-gradient2">
              50
              <span class="text-2xl"> % </span>
            </h3>
            <p class="text-xl font-medium text-black1 font-urbanist mt-8 pr-5">
              Faster launch timelines
            </p>
          </div>
        </div>
        <!-- Testimonial Slider -->
        <div
          id="testimonial-slider"
          class="overflow-hidden relative w-full max-w-full order-1 lg:order-2 z-20"
        >
          <div
            id="testimonial-track"
            class="flex transition-transform duration-500 ease-in-out w-full"
            style="width: 100%"
          >
            <!-- Slide 1 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none"
            >
              <div class="w-10 flex flex-col items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
                <div
                  class="bg-gradient2 w-[2px] flex-grow"
                  style="height: 120px"
                ></div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  Our team was struggling with slow transaction processing and outdated legacy systems that couldn’t handle the increasing load. Intellivon's digital product engineering services helped us modernize our infrastructure with cloud-native solutions and microservices. This has improved our transaction processing speed by 40%, allowing us to serve more customers with greater efficiency.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    Sarah T., CTO 
                  </div>
                </div>
              </div>
            </div>
            <!-- Slide 2 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none"
            >
              <div class="w-10 flex flex-col items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
                <div
                  class="bg-gradient2 w-[2px] flex-grow"
                  style="height: 120px"
                ></div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  We were facing challenges in personalizing our customer experience due to fragmented data systems. Intellivon seamlessly integrated our data sources and built a recommendation engine using machine learning, enabling us to offer personalized product suggestions. This resulted in a 25% increase in conversion rates and significantly improved customer satisfaction.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    John M., Head of Product.
                  </div>
                </div>
              </div>
            </div>
            <!-- Slide 3 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none"
            >
              <div class="w-10 flex flex-col items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
                <div
                  class="bg-gradient2 w-[2px] flex-grow"
                  style="height: 120px"
                ></div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  Our platform's user experience was suffering from inconsistent performance, and our tech stack couldn’t scale to meet the growing demand. Intellivon’s team overhauled our platform architecture, moving us to a microservices-based architecture with AWS cloud services. The result was a 50% improvement in system uptime, allowing us to serve our growing user base better.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    Emily R., CEO
                  </div>
                </div>
              </div>
            </div>
            <!-- Slide 4 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none"
            >
              <div class="w-10 flex flex-col items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
                <div
                  class="bg-gradient2 w-[2px] flex-grow"
                  style="height: 120px"
                ></div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  Our legacy system was causing delays in order fulfillment and poor customer service. Intellivon helped us modernize our order processing system by implementing real-time data streaming with Apache Kafka. This improved our order fulfillment time by 35% and resulted in a 20% boost in customer satisfaction ratings.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    Michael B., COO 
                  </div>
                </div>
              </div>
            </div>
            <!-- Slide 5 -->
            <div
              class="slide min-w-full shrink-0 common-whitebox2 px-6 p-5 rounded-lg flex h-fit relative w-full shadow-lg md:shadow-none"
            >
              <div class="w-10 flex flex-col items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M20 24H10C9.46957 24 8.96086 23.7893 8.58579 23.4142C8.21071 23.0391 8 22.5304 8 22V15C8 14.4696 8.21071 13.9609 8.58579 13.5858C8.96086 13.2107 9.46957 13 10 13H18C18.5304 13 19.0391 13.2107 19.4142 13.5858C19.7893 13.9609 20 14.4696 20 15V24ZM20 24C20 29 18 32 12 35M40 24H30C29.4696 24 28.9609 23.7893 28.5858 23.4142C28.2107 23.0391 28 22.5304 28 22V15C28 14.4696 28.2107 13.9609 28.5858 13.5858C28.9609 13.2107 29.4696 13 30 13H38C38.5304 13 39.0391 13.2107 39.4142 13.5858C39.7893 13.9609 40 14.4696 40 15V24ZM40 24C40 29 38 32 32 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
                <div
                  class="bg-gradient2 w-[2px] flex-grow"
                  style="height: 120px"
                ></div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                >
                  <path
                    d="M28 24H38C38.5304 24 39.0391 23.7893 39.4142 23.4142C39.7893 23.0391 40 22.5304 40 22V15C40 14.4696 39.7893 13.9609 39.4142 13.5858C39.0391 13.2107 38.5304 13 38 13H30C29.4696 13 28.9609 13.2107 28.5858 13.5858C28.2107 13.9609 28 14.4696 28 15V24ZM28 24C28 29 30 32 36 35M8 24H18C18.5304 24 19.0391 23.7893 19.4142 23.4142C19.7893 23.0391 20 22.5304 20 22V15C20 14.4696 19.7893 13.9609 19.4142 13.5858C19.0391 13.2107 18.5304 13 18 13H10C9.46957 13 8.96086 13.2107 8.58578 13.5858C8.21071 13.9609 8 14.4696 8 15V24ZM8 24C8 29 10 32 16 35"
                    stroke="black"
                    stroke-width="3"
                    stroke-linecap="round"
                  />
                </svg>
              </div>
              <div class="pl-6 h-fit pt-4">
                <div class="flex flex-col gap-5 font-normal text-black1 mt-5">
                  We were losing valuable insights due to inefficient data collection methods, which made it difficult to optimize energy consumption. Intellivonbuilt a real-time analytics platform using Apache Flink and AWS, enabling us to track and analyze energy usage instantly. As a result, we reduced energy waste by 30%, leading to significant operational cost savings.
                  <div class="text-xl font-medium font-urbanist text-black1">
                    Jessica L., Director of Operations
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            id="testimonial-dots"
            class="flex items-center justify-center gap-2 mt-5"
          ></div>
        </div>
      </div>
    </div>
  </div>
  <!-- Testimonial Script -->
  <script>
    const testimonialSlider = document.getElementById("testimonial-slider");
    const testimonialTrack = document.getElementById("testimonial-track");
    const testimonialSlides = document.querySelectorAll(
      "#testimonial-track .slide"
    );
    const testimonialPrev = document.getElementById("testimonial-prev");
    const testimonialNext = document.getElementById("testimonial-next");
    const testimonialDots = document.getElementById("testimonial-dots");

    let testimonialIndex = 0;
    const testimonialVisibleDots = 3;
    const testimonialTotalSlides = testimonialSlides.length;

    function updateTestimonialDots() {
      const currentDotGroup = Math.floor(
        testimonialIndex / testimonialVisibleDots
      );
      testimonialDots.innerHTML = "";
      for (let i = 0; i < testimonialVisibleDots; i++) {
        const dotIndex = currentDotGroup * testimonialVisibleDots + i;
        if (dotIndex >= testimonialTotalSlides) break;
        const dot = document.createElement("div");
        dot.className =
          "h-[12px] rounded-full bg-gradient-to-r from-[#7C3BAF] to-[#E61C42] transition-all duration-300";
        dot.style.width = dotIndex === testimonialIndex ? "70px" : "28px";
        dot.style.opacity = dotIndex === testimonialIndex ? "1" : "0.5";
        testimonialDots.appendChild(dot);
      }
    }

    function updateTestimonialSlider() {
      testimonialTrack.style.transform = `translateX(-${
        testimonialIndex * 100
      }%)`;
      updateTestimonialDots();
    }

    testimonialNext.addEventListener("click", () => {
      testimonialIndex = (testimonialIndex + 1) % testimonialTotalSlides;
      updateTestimonialSlider();
    });

    testimonialPrev.addEventListener("click", () => {
      testimonialIndex =
        (testimonialIndex - 1 + testimonialTotalSlides) %
        testimonialTotalSlides;
      updateTestimonialSlider();
    });

    updateTestimonialSlider();
    // Auto-slide every 2 seconds
    setInterval(() => {
      testimonialIndex = (testimonialIndex + 1) % testimonialTotalSlides;
      updateTestimonialSlider();
    }, 2000);
  </script>
</section>

<!-- BLOGS -->
<!-- BLOGS Section with Swiper -->
<section class="py-24 w-full bg-cover px-5 lg:px-10 relative overflow-hidden">
  <div class="container">
    <div class="flex items-end justify-between mt-6 mb-3 w-full">
      <div class="w-full">
        <div class="w-full flex flex-col gap-5 items-start">
          <div class="text-md font-semibold text-[#656565]">BLOGS</div>
          <div
            class="flex flex-col lg:flex-row gap-5 lg:gap-0 w-full justify-between"
          >
            <div
              class="w-full text-4xl flex-wrap gap-3 flex items-center font-bold text-black1 font-urbanist"
            >
              The Latest from
              <div class="text-gradient">Intellivon</div>
            </div>
            <div class="lg:w-1/3">
              <a href="https://intellivon.com/blog/" target="_blank">
                <button
                  type="button"
                  class="relative px-3 py-3 w-fit flex justify-center text-white font-medium rounded-full bg-white overflow-hidden group"
                >
                  <span
                    class="relative z-10 text-blue text-nowrap text-sm lg:text-md items-center lg:items-normal flex gap-2"
                  >
                    Know More About Our Insights
                    <img
                      src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/know-more-capabilities-arrow.svg"
                    />
                  </span>
                  <div
                    class="absolute inset-0 bg-gradient-to-l from-[#ab00ff] via-[#7000eb] to-[#00c8eb] rounded-full p-[1px]"
                  >
                    <div class="h-full w-full bg-white rounded-full"></div>
                  </div>
                </button>
              </a>
            </div>
          </div>
          <h3 class="text-grey1 text-base font-medium lg:w-1/2">
            Our exclusive platform where we share expert perspectives and
            guidance for your AI journey.
          </h3>
          <div class="flex gap-5 w-full items-center z-10">
            <?php echo do_shortcode( '[elementor-template id="1908"]'); ?>
          </div>
        </div>
      </div>
    </div>
    <!-- Background Decoration -->
    <div
      class="absolute right-0 top-0 w-[468px] h-[634px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="468"
        height="634"
        viewBox="0 0 468 634"
        fill="none"
      >
        <g filter="url(#filter0_f_47_15221)">
          <path
            d="M564 197C564 126.86 507.14 70 437 70C366.86 70 310 126.86 310 197C310 267.14 366.86 324 437 324C507.14 324 564 267.14 564 197Z"
            fill="#7C3BAF"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_47_15221"
            x="0.200012"
            y="-239.8"
            width="873.6"
            height="873.6"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="154.9"
              result="effect1_foregroundBlur_47_15221"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div
      class="absolute left-0 top-[30%] w-[407px] h-[823px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="407"
        height="823"
        viewBox="0 0 407 823"
        fill="none"
      >
        <g filter="url(#filter0_f_47_15222)">
          <path
            d="M97 437C97 366.86 40.1402 310 -30 310C-100.14 310 -157 366.86 -157 437C-157 507.14 -100.14 564 -30 564C40.1402 564 97 507.14 97 437Z"
            fill="#E61C42"
            fill-opacity="0.6"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_47_15222"
            x="-466.8"
            y="0.200012"
            width="873.6"
            height="873.6"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="154.9"
              result="effect1_foregroundBlur_47_15222"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div
      class="hidden lg:block absolute left-[30%] top-[30%] w-[821px] h-[744px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="821"
        height="744"
        viewBox="0 0 821 744"
        fill="none"
        class="w-max-20"
      >
        <g filter="url(#filter0_f_47_15226)">
          <path
            d="M511 410.5C511 354.995 466.005 310 410.5 310C354.995 310 310 354.995 310 410.5C310 466.005 354.995 511 410.5 511C466.005 511 511 466.005 511 410.5Z"
            fill="#E61C42"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_47_15226"
            x="0.200012"
            y="0.200012"
            width="820.6"
            height="820.6"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="154.9"
              result="effect1_foregroundBlur_47_15226"
            />
          </filter>
        </defs>
      </svg>
    </div>
  </div>
</section>

<!-- CONTACT US FORM START -->
<section class="w-full relative bg-[#E4EAF2] py-20 px-5 lg:px-10">
  <div class="flex flex-col gap-8 container">
    <div class="text-md font-semibold text-[#656565]">CONTACT US</div>
    <div class="text-4xl leading-[1.25] font-semibold mt-10 lg:mt-0">
      Connect with Our
      <span class="text-gradient"> AI Experts </span>
      Today
    </div>
    <div class="w-full py-8">
      <?php echo do_shortcode( '[wpforms id="88"]'); ?>
    </div>
  </div>
</section>
<!-- CONTACT US FORM END -->

<!-- FAQ -->
<!-- Complete FAQ Section with Accordion and Smooth Transition -->
<section
  class="w-full px-5 lg:px-10 py-14 lg:py-20 bg-[#E4EAF2] relative overflow-hidden"
>
  <div class="container flex flex-col gap-5 items-center">
    <!-- Heading -->
    <div class="flex justify-between items-center w-full">
      <div class="text-md font-semibold text-[#656565]">FAQ</div>
    </div>
    <div class="flex flex-col w-5/6 mt-5">
      <!-- FAQ Item 1 -->
      <div class="faq-item">
        <div
          class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer"
        >
          <div class="font-medium text-xl">
            Q1. What is Digital Product Engineering and why is it important?
          </div>
          <div class="faq-icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="27"
              height="27"
              viewBox="0 0 27 27"
              fill="none"
            >
              <!-- vertical line -->
              <path
                class="vertical-path"
                d="M13.2227 2.61133V23.7671"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <!-- horizontal line -->
              <path
                d="M23.8008 13.1895L2.645 13.1895"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </div>
        <div
          class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8"
        >
          <p class="text-base text-[#333]">
            Digital Product Engineering is the process of designing, developing, and optimizing digital products, including mobile apps, platforms, and software solutions. It combines product design, software engineering, and technological innovation to create scalable and user-focused products. It's crucial because it enables businesses to build high-quality, competitive digital solutions that meet market demands and deliver exceptional user experiences.
          </p>
        </div>
      </div>
      <!-- FAQ Item 2 -->
      <div class="faq-item">
        <div
          class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer"
        >
          <div class="font-medium text-xl">
            Q2. How does Intellivon’s Digital Product Engineering process work?
          </div>
          <div class="faq-icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="27"
              height="27"
              viewBox="0 0 27 27"
              fill="none"
            >
              <path
                class="vertical-path"
                d="M13.2227 2.61133V23.7671"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M23.8008 13.1895L2.645 13.1895"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </div>
        <div
          class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8"
        >
          <p class="text-base text-[#333]">
            Intellivon follows a structured, collaborative process that begins with understanding your business needs, followed by ideation, product design, and agile development. We focus on creating user-centric products using cutting-edge technologies and ensure quality with rigorous testing. Post-launch, we provide continuous support and enhancements, helping your product evolve as your business grows.
          </p>
        </div>
      </div>
      <!-- FAQ Item 3 -->
      <div class="faq-item">
        <div
          class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer"
        >
          <div class="font-medium text-xl">
            Q3. What technologies does Intellivon use in Digital Product Engineering?
          </div>
          <div class="faq-icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="27"
              height="27"
              viewBox="0 0 27 27"
              fill="none"
            >
              <path
                class="vertical-path"
                d="M13.2227 2.61133V23.7671"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M23.8008 13.1895L2.645 13.1895"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </div>
        <div
          class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8"
        >
          <p class="text-base text-[#333]">
            Intellivon nutilizes a broad tech stack including cloud-native technologies like AWS, GCP, and Azure, along with modern frameworks like React.js, Node.js, and Kubernetes. We integrate AI, machine learning, and real-time data processing tools such as Apache Kafka and Apache Spark to build scalable, secure, and innovative digital products that drive business success.
          </p>
        </div>
      </div>
      <!-- FAQ Item 4 -->
      <div class="faq-item">
        <div
          class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer"
        >
          <div class="font-medium text-xl">
            Q4. How do our Digital Product Engineering services help businesses scale?
          </div>
          <div class="faq-icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="27"
              height="27"
              viewBox="0 0 27 27"
              fill="none"
            >
              <path
                class="vertical-path"
                d="M13.2227 2.61133V23.7671"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M23.8008 13.1895L2.645 13.1895"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </div>
        <div
          class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8"
        >
          <p class="text-base text-[#333]">
            Our services help businesses scale by modernizing legacy systems, improving operational efficiency, and building cloud-native, microservices-based architectures. We ensure that digital products can handle increased user demand, optimize performance, and seamlessly integrate with new technologies, enabling businesses to stay competitive in a rapidly evolving market.
          </p>
        </div>
      </div>
      <!-- FAQ Item 5 -->
      <div class="faq-item">
        <div
          class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer"
        >
          <div class="font-medium text-xl">
            Q5. Can Intellivon help with both product development and ongoing support?
          </div>
          <div class="faq-icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="27"
              height="27"
              viewBox="0 0 27 27"
              fill="none"
            >
              <path
                class="vertical-path"
                d="M13.2227 2.61133V23.7671"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M23.8008 13.1895L2.645 13.1895"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </div>
        <div
          class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8"
        >
          <p class="text-base text-[#333]">
            Yes, Intellivon provides end-to-end services from initial product strategy and development to post-launch support. Our managed sustenance services ensure that your product remains competitive and evolves with your business needs. We offer proactive monitoring, updates, and enhancements to help your product adapt and grow over time.
          </p>
        </div>
      </div>

      <!-- FAQ Item 6 -->
      <div class="faq-item">
        <div
          class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer"
        >
          <div class="font-medium text-xl">
            Q6. How long does it take to develop a digital product with Intellivon?
          </div>
          <div class="faq-icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="27"
              height="27"
              viewBox="0 0 27 27"
              fill="none"
            >
              <path
                class="vertical-path"
                d="M13.2227 2.61133V23.7671"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M23.8008 13.1895L2.645 13.1895"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </div>
        <div
          class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8"
        >
          <p class="text-base text-[#333]">
            The timeline for developing a digital product depends on the project’s complexity and scope. Generally, we start with a discovery phase to define requirements, followed by design, development, and testing. For most products, the initial version can take 8–12 weeks, but ongoing iterations and enhancements continue even after the launch, ensuring the product evolves with your business needs
          </p>
        </div>
      </div>

      <!-- FAQ Item 7 -->
      <div class="faq-item">
        <div
          class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer"
        >
          <div class="font-medium text-xl">
            Q7. What industries does Intellivon provide Digital Product Engineering services to?
          </div>
          <div class="faq-icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="27"
              height="27"
              viewBox="0 0 27 27"
              fill="none"
            >
              <path
                class="vertical-path"
                d="M13.2227 2.61133V23.7671"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M23.8008 13.1895L2.645 13.1895"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </div>
        <div
          class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8"
        >
          <p class="text-base text-[#333]">
            Intellivon has experience working across various industries, including fintech, healthcare, e-commerce, energy, and more. We tailor our digital product engineering solutions to meet the specific needs of each industry, ensuring that the products we deliver are both innovative and aligned with industry standards.
          </p>
        </div>
      </div>

      <!-- FAQ Item 8 -->
      <div class="faq-item">
        <div
          class="border-t border-[#7C3BAF] flex justify-between py-5 cursor-pointer"
        >
          <div class="font-medium text-xl">
            Q8. How does Intellivon ensure the quality of digital products during development?
          </div>
          <div class="faq-icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="27"
              height="27"
              viewBox="0 0 27 27"
              fill="none"
            >
              <path
                class="vertical-path"
                d="M13.2227 2.61133V23.7671"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M23.8008 13.1895L2.645 13.1895"
                stroke="black"
                stroke-width="4.6301"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </div>
        <div
          class="faq-answer overflow-hidden max-h-0 opacity-0 transition-all duration-300 ease-in-out px-4 pb-8"
        >
          <p class="text-base text-[#333]">
            Intellivon ensures the high quality of its digital products by implementing a robust quality assurance process, which includes test automation, continuous integration, and thorough manual testing. We prioritize performance, security, and usability to ensure that the product meets your business goals and provides a seamless user experience from launch onward.
          </p>
        </div>
      </div>
    </div>

    <!-- Background Decoration unchanged -->
    <div
      class="absolute top-0 right-0 w-[481px] h-[527px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="481"
        height="527"
        viewBox="0 0 481 527"
        fill="none"
      >
        <g filter="url(#filter0_f_342_636)">
          <path
            d="M486 184.5C486 263.201 421.977 327 343 327C264.023 327 200 263.201 200 184.5C200 105.799 264.023 42 343 42C421.977 42 486 105.799 486 184.5Z"
            fill="#E61C42"
            fill-opacity="0.2"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_342_636"
            x="0"
            y="-158"
            width="686"
            height="685"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="100"
              result="effect1_foregroundBlur_342_636"
            />
          </filter>
        </defs>
      </svg>
    </div>
    <div
      class="absolute bottom-2 left-0 w-[453px] h-[595px] overflow-hidden pointer-events-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="453"
        height="595"
        viewBox="0 0 453 595"
        fill="none"
      >
        <g filter="url(#filter0_f_342_637)">
          <path
            d="M253 342.5C253 421.201 188.977 485 110 485C31.0233 485 -33 421.201 -33 342.5C-33 263.799 31.0233 200 110 200C188.977 200 253 263.799 253 342.5Z"
            fill="#7C3BAF"
            fill-opacity="0.3"
          />
        </g>
        <defs>
          <filter
            id="filter0_f_342_637"
            x="-233"
            y="0"
            width="686"
            height="685"
            filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
            />
            <feGaussianBlur
              stdDeviation="100"
              result="effect1_foregroundBlur_342_637"
            />
          </filter>
        </defs>
      </svg>
    </div>
  </div>
</section>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".faq-item").forEach((item) => {
      const questionDiv = item.querySelector(".cursor-pointer");
      const answerDiv = item.querySelector(".faq-answer");
      const svgIcon = item.querySelector("svg");
      const verticalPath = svgIcon.querySelector(".vertical-path");

      questionDiv.addEventListener("click", () => {
        const isCollapsed =
          !answerDiv.style.maxHeight || answerDiv.style.maxHeight === "0px";

        if (isCollapsed) {
          // Open: set maxHeight to content height, opacity to 1
          const scrollH = answerDiv.scrollHeight;
          answerDiv.style.maxHeight = scrollH + "px";
          answerDiv.style.opacity = "1";
          // Hide vertical line to become minus
          if (verticalPath) verticalPath.style.display = "none";
        } else {
          // Close: collapse
          answerDiv.style.maxHeight = "0";
          answerDiv.style.opacity = "0";
          // Show vertical line again (plus)
          if (verticalPath) verticalPath.style.display = "";
        }
      });
    });
  });
</script>
<?php get_footer(); ?>
